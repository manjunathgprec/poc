package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.config;

import java.util.HashMap;
import java.util.Map;

import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.ApplicationPropertyConfig;

@Configuration
@EnableKafka
public class KafkaConfig {
	
	
	@Autowired
	private ApplicationPropertyConfig appProperties;
	
	@Autowired
	KafkaListenerEndpointRegistry kafkaListenerRegistry;

	
	//Kafka producer config
	@Bean
	public ProducerFactory<String, Object> producerFactory() {
		Map<String, Object> props = new HashMap<String, Object>();
		props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, appProperties.getKafkaproducerpropmap().get("kafka.bootstrapServers"));
		props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
		props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
		props.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, appProperties.getKafkaproducerpropmap().get("kafka.securityProtocol"));
		props.put(SaslConfigs.SASL_MECHANISM, appProperties.getKafkaproducerpropmap().get("kafka.saslMechanism"));
		props.put(SaslConfigs.SASL_JAAS_CONFIG,appProperties.getKafkaproducerpropmap().get("kafka.saslJaas"));

		return new DefaultKafkaProducerFactory<String, Object>(props);
	}

	@Bean
	public KafkaTemplate<String, Object> kafkaTemplate() {
		return new KafkaTemplate<String, Object>(producerFactory());
	}
	
	
	
	//Kafka consumer config
	@Bean
	public Map<String, Object> consumerConfigs() {
		Map<String, Object> props = new HashMap<String, Object>();
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, appProperties.getKafkaconsumerpropmap().get("kafka.bootstrapServers"));
		props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
		props.put(ConsumerConfig.GROUP_ID_CONFIG, appProperties.getKafkaconsumerpropmap().get("kafka.groupIdConfig"));
		props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, appProperties.getKafkaconsumerpropmap().get("kafka.enableAutoCommit"));	
		props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG,appProperties.getKafkaconsumerpropmap().get("kafka.maxPollRecords"));
		props.put(AdminClientConfig.SECURITY_PROTOCOL_CONFIG, appProperties.getKafkaconsumerpropmap().get("kafka.securityProtocol"));
		props.put(SaslConfigs.SASL_MECHANISM, appProperties.getKafkaconsumerpropmap().get("kafka.saslMechanism"));
		props.put(SaslConfigs.SASL_JAAS_CONFIG, appProperties.getKafkaconsumerpropmap().get("kafka.saslJaas"));
		return props;
	}

	
	
	@Bean
	public ConsumerFactory<Long, String> consumerFactory() {
		return new DefaultKafkaConsumerFactory<Long, String>(consumerConfigs(), new LongDeserializer(),
				new StringDeserializer());
	}
    
	@Bean
	public ConcurrentKafkaListenerContainerFactory<Long, String> kafkaListenerContainerFactory( ) {
		ConcurrentKafkaListenerContainerFactory<Long, String> factory = new ConcurrentKafkaListenerContainerFactory<Long, String>();
		factory.setConsumerFactory(consumerFactory());
		  return factory;
		
	}
	
	
	/*
	 * @Scheduled(fixedRate = 3600000 )//3600000 - 1hr public void
	 * restartListenerIfDown() {
	 * logger.info("Starting Job restartListenerIfDown {}", LocalDateTime.now());
	 * for(MessageListenerContainer listenerContainer :
	 * kafkaListenerRegistry.getListenerContainers()) { try {
	 * if(!listenerContainer.isRunning()) {
	 * logger.error("Listener is not running, restarting the listener");
	 * listenerContainer.start(); } }catch(Exception e) {
	 * logger.error("Error while restarting container: "+e.getMessage()); }
	 * MDC.put("ListenerStatus", listenerContainer.isRunning()); } }
	 */

}
