package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics.SplunkLOGInterceptor;




/**
 * @author af36496
 *
 * @version $Revision: 1.0 $
 */
@Configuration
public class WebMvcConfig extends WebMvcConfigurerAdapter {

	/**
	 * Method splunkLOGInterceptor.
	 * @return SplunkLOGInterceptor
	 */
	@Bean
	public SplunkLOGInterceptor splunkLOGInterceptor(){
		
		return new SplunkLOGInterceptor();
	}
	
	/**
	 * Method addInterceptors.
	 * @param registry InterceptorRegistry
	 * @see org.springframework.web.servlet.config.annotation.WebMvcConfigurer#addInterceptors(InterceptorRegistry)
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
       
        registry.addInterceptor(splunkLOGInterceptor());
    }
    
    /**
     * Method applicationContextProvider.
     * @return ApplicationContextProvider
     */
	
	/*
	 * @Bean public ApplicationContextProvider applicationContextProvider(){
	 * 
	 * return new ApplicationContextProvider(); }
	 */
	
	
	
}