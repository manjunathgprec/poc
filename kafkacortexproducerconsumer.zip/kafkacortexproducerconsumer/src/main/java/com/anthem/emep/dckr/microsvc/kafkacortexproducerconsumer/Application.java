package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;




/**
 * Docker MS Prototype!
 *
 */

@SpringBootApplication
@ComponentScan(value = { "com.anthem" })
@RefreshScope
@EnableAspectJAutoProxy(proxyTargetClass = false)
public class Application {
	


	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

		
	
}
