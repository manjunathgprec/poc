package com.anthem.emep.dckr.microsvc.kafkacortexconsumer.utils;

import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DateTimeFormatterUtil {
	private static DateTimeFormatter df = DateTimeFormat.forPattern("yyyyMMdd");
	private static DateTimeFormatter dfwdash = DateTimeFormat.forPattern("yyyy-MM-dd");
	private static DateTimeFormatter dateTime = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS");
	  
	static public String printCurrentDateTime() {
		 
		LocalDateTime localDateTime = new LocalDateTime();
	    return  localDateTime.toString(dateTime);
	  }
	
	static public String totalResponseTimeInSeconds(String date1, String date2) {
		 
		DateTime startDate = dateTime.parseDateTime(date1);
		DateTime endDate = dateTime.parseDateTime(date2);
	
		long totalResponseTime = endDate.getMillis() - startDate.getMillis();

	    return  String.valueOf(totalResponseTime);
	  }
	
	
	 static public String printCalendarNoDash(Calendar c) {
		 if(c==null)return null;
		  else
	    return new DateTime(c).toString(df);
	  }
	  
	 static public String convertToYYYYMMDD(Timestamp c) {
		 if(c==null)return null;
		  else
	    return dateTime.parseLocalDate(c.toString()).toString(dfwdash);
	  }
	  
	  static public String convertToYYYYMMDD(String c) {
		  if(c==null)return null;
		  else
		    return dfwdash.parseLocalDate(c).toString(df);
		  }
	  
	  static public String convertToYYYY_MM_DD(String c) {
		  if(c==null)return null;
		  else	 
		  return df.parseLocalDate(c).toString(dfwdash);
		  } 
	  
	  static public String printCalendar(Calendar c) {
		  if(c==null)return null;
		  else
		    return  new DateTime(c).toString(dfwdash);
		  }
	  
	  static public String printDate(Date c) {
		  	if(c==null)return null;
		  else
			  return  new DateTime(c).toString(dfwdash);
		  }
	  
	  static public String printDateNoDash(Date c) {
		  if(c==null)return null;
		  else
		  return  new DateTime(c).toString(df);
		  }
	  
	  static public String printDate(LocalDate c) {
		  if(c==null)return null;
		  else
		  return  new DateTime(c).toString(dfwdash);
		  }
	  
	  static public String printDateNoDash(LocalDate c) {
		  if(c==null)return null;
		  else
		  return  new DateTime(c).toString(df);
		  }

	  static public Calendar parseCalendar(String c) {
		  Calendar cal = Calendar.getInstance();  
			try{  
			
		    cal.setTime(dfwdash.parseDateTime(c).toDate());
			}catch(Exception e){
				
			}
	    return cal;
	  }
	  
	  static public Calendar parseCalendarNoDash(String c) {
		  Calendar cal = Calendar.getInstance();  
			try{  
			
		    cal.setTime(df.parseDateTime(c).toDate());
			}catch(Exception e){
				
			}
	    return cal;
	  }
}