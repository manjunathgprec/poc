package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.feedback.model;

public class InsightFeedbackPayloadData {
	

	 private String profileId;

	    private String insightId;

	    private boolean feedback;

	    public void setProfileId(String profileId){
	        this.profileId = profileId;
	    }
	    public String getProfileId(){
	        return this.profileId;
	    }
	    public void setInsightId(String insightId){
	        this.insightId = insightId;
	    }
	    public String getInsightId(){
	        return this.insightId;
	    }
	    public void setFeedback(boolean feedback){
	        this.feedback = feedback;
	    }
	    public boolean getFeedback(){
	        return this.feedback;
	    }
	
	
}
