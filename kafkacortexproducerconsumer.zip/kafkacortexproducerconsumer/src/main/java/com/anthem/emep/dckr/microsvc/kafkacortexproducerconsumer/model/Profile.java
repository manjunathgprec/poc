package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model;

import java.io.IOException;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Document(collection = "sxCogScaleInsightObjects")
public class Profile {


	@Id
	private String id;
	
	private String profileId;
	
	private Insight insight;
	
	private String timestamp;
	
	private String status;
	
	private String model_version;
	
	@Transient
	private IdRecord _id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProfileId() {
		return profileId;
	}

	public void setProfileId(String profileId) {
		this.profileId = profileId;
	}

	public Insight getInsight() {
		return insight;
	}

	public void setInsight(Insight insight) {
		this.insight = insight;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getModel_version() {
		return model_version;
	}

	public void setModel_version(String model_version) {
		this.model_version = model_version;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		//result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((insight == null) ? 0 : insight.hashCode());
		result = prime * result + ((model_version == null) ? 0 : model_version.hashCode());
		result = prime * result + ((profileId == null) ? 0 : profileId.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Profile other = (Profile) obj;
		/*if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;*/
		if (insight == null) {
			if (other.insight != null)
				return false;
		} else if (!insight.equals(other.insight))
			return false;
		if (model_version == null) {
			if (other.model_version != null)
				return false;
		} else if (!model_version.equals(other.model_version))
			return false;
		if (profileId == null) {
			if (other.profileId != null)
				return false;
		} else if (!profileId.equals(other.profileId))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (timestamp == null) {
			if (other.timestamp != null)
				return false;
		} else if (!timestamp.equals(other.timestamp))
			return false;
		return true;
	}

	public Profile(String id, String profileId, Insight insight, String timestamp, String status,
			String model_version) {
		super();
		//this.id = id;
		this.profileId = profileId;
		this.insight = insight;
		this.timestamp = timestamp;
		this.status = status;
		this.model_version = model_version;
	}

	@Override
	public String toString() {
		return "Profile [id=" + "id" + ", profileId=" + profileId + ", insight=" + insight + ", timestamp="
				+ timestamp + ", status=" + status + ", model_version=" + model_version + "]";
	}
	
	public Profile() {
		
	}
	
	/*Deserializing quoted JSON string gave the exception 
	 * com.fasterxml.jackson.databind.JsonMappingException: Can not instantiate value of type [simple type, 
	 * class com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.Profile] from String value; no single-String constructor/factory method. 
	 * To fix this exception you need to give string parameter constructor or one static factory method with single string parameter with attribute @JsonCreator.
	 * */
	//Method to deserialize quoted JSON string
	@JsonCreator
	public static Profile Create(String jsonString) throws JsonParseException, JsonMappingException, IOException {
	    ObjectMapper mapper = new ObjectMapper();
	    Profile profile = null;
	    profile = mapper.readValue(jsonString, Profile.class);
	    return profile;
	}

	public IdRecord get_id() {
		return _id;
	}

	public void set_id(IdRecord _id) {
		this._id = _id;
	}
	
	
}
