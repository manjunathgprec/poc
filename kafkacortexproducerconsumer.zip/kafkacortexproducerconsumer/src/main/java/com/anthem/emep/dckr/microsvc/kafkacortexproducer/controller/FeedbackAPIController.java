package com.anthem.emep.dckr.microsvc.kafkacortexproducer.controller;

import static com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants.BASEPATH;
import static com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants.INSIGHTFEEDBACK;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.anthem.emep.dckr.microsvc.kafkacortexproducer.service.FeedBackService;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.feedback.model.InsightFeedbackRequest;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics.MethodMetric;


/**
 * DCC-1361 
 * Given an insight feedback is sent by consumer (RCP/SC)
When Rest API layer captures the feedback and converts into Kafka Message
Then Pitch the feedback message to the Cog-scale topic for Cogscale to consume.
When captured feedback is being converted into Kafka message
Then META_ACTION should always be "UPDATE"
And Seed the Date time Stamp when this message was created in the META_CREATE_DTTM element.
 *
 */
@RestController
@RequestMapping(value = BASEPATH)
public class FeedbackAPIController {
	
	@Autowired
	private FeedBackService service;
	
	private static final Logger logger = LoggerFactory.getLogger(FeedbackAPIController.class);

	
	@MethodMetric
	@RequestMapping(value = INSIGHTFEEDBACK, method = RequestMethod.POST)
	public String sendInsightFeedBackToCogScale(@RequestBody InsightFeedbackRequest feedback) {
		logger.info(Constants.ENTERING_FEEDBACK_CONTROLLER);
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		logger.info("{}{}",Constants.REST_TRANSACTION , stopWatch.getTotalTimeMillis());
		
		String message = service.sendInsightFeedback(feedback);
		
		stopWatch.stop();
		logger.info("{}{}",Constants.EXITING_FEEDBACK_CONTROLLER_TIME_TAKEN , stopWatch.getTotalTimeMillis());
		return  message;
	}

}
