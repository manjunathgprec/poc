package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics;

import org.springframework.stereotype.Component;

@Component
public class RequestHeader {
	private String consumerId = "NA";
	private String transId;
	private String messageId = "NA";
	private String nodeName;
	private String nodeIp;
	private String nodePort;
	private String requestURI;
	private String contextPath;
	private String responseStatus;


	public String getConsumerId() {
		return this.consumerId;
	}

	public void setConsumerId(String consumerId) {
		this.consumerId = consumerId;
	}

	public String getTransId() {
		return this.transId;
	}

	public void setTransId(String transId) {
		this.transId = transId;
	}

	public String getMessageId() {
		return this.messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getNodeName() {
		return this.nodeName;
	}

	public void setNodeName(String nodeName) {
		this.nodeName = nodeName;
	}

	public String getRequestURI() {
		return this.requestURI;
	}

	public void setRequestURI(String requestURI) {
		this.requestURI = requestURI;
	}

	public String getContextPath() {
		return this.contextPath;
	}

	public void setContextPath(String contextPath) {
		this.contextPath = contextPath;
	}

	public String getNodeIp() {
		return this.nodeIp;
	}

	public void setNodeIp(String nodeIp) {
		this.nodeIp = nodeIp;
	}

	public String getNodePort() {
		return this.nodePort;
	}

	public void setNodePort(String nodePort) {
		this.nodePort = nodePort;
	}
	
	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	@Override
	public String toString() {
		return "RequestHeader [consumerId=" + this.consumerId + ", transId="
				+ this.transId + ", messageId=" + this.messageId
				+ ", nodeName=" + this.nodeName + ", nodeIp=" + this.nodeIp
				+ ", nodePort=" + this.nodePort + ", requestURI="
				+ this.requestURI + ", responseStatus=" + responseStatus + 
				", contextPath=" + this.contextPath + "]";
	}
}