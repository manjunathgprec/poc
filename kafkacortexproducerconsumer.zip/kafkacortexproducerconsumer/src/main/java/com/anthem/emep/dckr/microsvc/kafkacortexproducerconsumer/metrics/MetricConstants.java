package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics;


public class MetricConstants {

	
	
	public static String BACKEND = "BACKEND";
	public static String THREADID = "ThreadId";
    public static String THREADNAME ="ThreadName";
    public static String THREADIDHEX ="ThreadIDHex";
    public static String NODE = "Node";
    public static String TRANID = "TranId";
    public static String CONSUMERSENDERID = "ConsumerSenderID";
    public static String CONSUMERSENDERID_VAL = "DCC";

    public static String URI = "URI";
    public static String TRANASACTIONSTARTTIME = "TranasactionStartTime";
    public static String TRANSACTIONENDTIME = "TransactionEndTime";
	public static  String BACKENDSTARTTIME = "BackendStartTime";
	public static  String BACKENDENDTIME = "BackendEndTime";
	public static String TOTALRESPONSETIME = "TotalResponseTime";
    public static String TRANSACTIONSTATUS = "TransactionStatus";
    public static String ERRORMSG = "ErrorMsg";
    public static String JDBCWAITTIME = "JDBCWaitTime";
    public static String JDBCINVOCATION = "JDBCInvocation";
    public static String CACHECONTENTFLAG = "CacheContentFlag";
    public static String CAPTURELOCATION = "CaptureLocation";

    public static String SERVICENAME = "ServiceName";
    public static String SERVICE_NAME_VAL = "kafkacortexproducerconsumer";

    public static String SERVICEVER = "ServiceVersion";
    public static String OPERNAME = "OperationName";
    public static String ERRORCD = "ErrorCode";
    public static String ERRORDT = "ErrorDetail";
    public static String STATUSCD = "StatusCode";
    public static String METHOD = "Method";
    public static String responseStatus = "NA";
    public static String targetURI = "targetURI";
    
    public static String PROFILEID = "ProfileId";
    
    public static String OPERATION = "Operation";
    public static String OPERATIONSTATUS = "OperationStatus";
    public static String OPERATIONERRORMSG = "OperationErrMsg";
	public static String OPERATIONSTATUSCD = "OperationStatusCode";

    public static String TOPIC = "Topic";
    public static String TOPICOFFSET = "TopicOffset";
    public static String TOPICPARTITION = "TopicPartition";
    public static String TOPICERRMSG ="KafkaTopicErrorMsg";
    public static String TOPICSUCMSG ="KafkaTopicSuccessMsg";
    
    public static String FAILED = "FAILED";
	public static  String SUCCESS = "SUCCESS";
	public static  String STATUSCD_400 = "400";
	public static  String STATUSCD_200 = "200";
	public static  String STATUSCD_500 = "500";
	
	

    
}