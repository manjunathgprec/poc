package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model;

public class IdRecord {

	private String timestamp;
	private String counter;
	private String randomValue1;
	private String randomValue2;
	
	public String getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}
	public String getCounter() {
		return counter;
	}
	public void setCounter(String counter) {
		this.counter = counter;
	}
	public String getRandomValue1() {
		return randomValue1;
	}
	public void setRandomValue1(String randomValue1) {
		this.randomValue1 = randomValue1;
	}
	public String getRandomValue2() {
		return randomValue2;
	}
	public void setRandomValue2(String randomValue2) {
		this.randomValue2 = randomValue2;
	}

}
