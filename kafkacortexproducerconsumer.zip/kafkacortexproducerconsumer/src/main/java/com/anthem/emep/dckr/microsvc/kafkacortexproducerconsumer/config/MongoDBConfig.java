package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.ApplicationPropertyConfig;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientURI;

@Configuration
public class MongoDBConfig {
	
	@Autowired
	private ApplicationPropertyConfig appConfig;
	
	/*Gets the server selection timeout in milliseconds, which defines how long the driver will wait for server selection to
     * succeed before throwing an exception. Default is 30,000. Value is configured in yml.*/
	@Value("${serverSelectionTimeout}") 
	private String serverSelectionTimeout;
	
	/*connection timeout in milliseconds. Default is  10,000  It is used solely when establishing a new connection. Value is configured in yml.*/
	@Value("${connectionTimeout}") 
	private String connectionTimeout;
	
	/*socket timeout in milliseconds.Default is 0. It is used for I/O socket read and write operations. Value is configured in yml.*/
	@Value("${socketTimeout}") 
	private String socketTimeout;
	
	@Bean(name = "mongoTemplate")
	public MongoTemplate mongoTemplate() throws Exception {
		return new MongoTemplate(mongoDbFactory());
	}

	@Bean
	public MongoDbFactory mongoDbFactory() throws Exception {
		
		MongoClientOptions.Builder builder = MongoClientOptions.builder().serverSelectionTimeout(Integer.parseInt(serverSelectionTimeout))
				 .connectTimeout(Integer.parseInt(connectionTimeout)).socketTimeout(Integer.parseInt(socketTimeout));
						
		return new SimpleMongoDbFactory(new MongoClientURI(appConfig.getMongodb().get(Constants.MONGO_DB_ECOMM_URI), builder));
		
	}

	
	
	

}
