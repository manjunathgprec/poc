package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix="applicationProperties")
public class ApplicationPropertyConfig {

	private Map<String, String> kafkaproducerpropmap;
	private Map<String, String> kafkaconsumerpropmap;
	private Map<String, String> mongodb;

	
	public Map<String, String> getMongodb() {
		return mongodb;
	}

	public void setMongodb(Map<String, String> mongodb) {
		this.mongodb = mongodb;
	}

	public Map<String, String> getKafkaproducerpropmap() {
		return kafkaproducerpropmap;
	}

	public void setKafkaproducerpropmap(Map<String, String> kafkaproducerpropmap) {
		this.kafkaproducerpropmap = kafkaproducerpropmap;
	}

	public Map<String, String> getKafkaconsumerpropmap() {
		return kafkaconsumerpropmap;
	}

	public void setKafkaconsumerpropmap(Map<String, String> kafkaconsumerpropmap) {
		this.kafkaconsumerpropmap = kafkaconsumerpropmap;
	}

	

	
}