package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.RequestContextFilter;

@Component
public class RequestFilter extends RequestContextFilter {
	@Autowired
	public RequestHeader requestHeader;
	private static final Logger splunklogger = LoggerFactory.getLogger("SPLUNK_TRACE");

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		if (this.requestHeader == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils
					.getWebApplicationContext(servletContext);
			this.requestHeader = (RequestHeader) webApplicationContext.getBean((Class) RequestHeader.class);
		}
		if (this.requestHeader != null && request != null) {
			String transactionId = request.getHeader("meta-transid");
			transactionId = transactionId != null && transactionId.trim().length() > 0 ? transactionId
					: UUID.randomUUID().toString();
			this.requestHeader.setTransId(transactionId);
			String consumerId = request.getHeader("meta-senderapp");
			consumerId = consumerId != null && consumerId.trim().length() > 0 ? consumerId
					: this.requestHeader.getConsumerId();
			this.requestHeader.setConsumerId(consumerId);
			this.requestHeader.setNodeName(request.getLocalAddr()); // getServerName()
			this.requestHeader.setNodeIp(request.getLocalAddr());
			this.requestHeader.setNodePort(String.valueOf(request.getLocalPort()));
			this.requestHeader.setContextPath(request.getContextPath());
			this.requestHeader.setRequestURI(request.getRequestURI());
			this.requestHeader.setMessageId(request.getHeader("meta-messageid"));
		}
		filterChain.doFilter(request, response);
		if (response.getStatus() == 200) {
			splunklogger.info("");
			MDC.clear();
		}
	}
}