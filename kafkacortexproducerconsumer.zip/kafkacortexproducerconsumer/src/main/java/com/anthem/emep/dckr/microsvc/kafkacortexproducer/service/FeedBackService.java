package com.anthem.emep.dckr.microsvc.kafkacortexproducer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import static com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants.META_ACTION;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.joda.time.*;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.feedback.model.InsightFeedbackRequest;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics.MethodMetric;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;



@Service
public class FeedBackService {
	private static final Logger logger = LoggerFactory.getLogger(FeedBackService.class);

	@Autowired
	private KafkaTemplate<String, Object> kafkaTemplate;
	 
	  @Value("${applicationProperties.kafkaproducerpropmap.kafka.feedBack.topic}")
	  private String topic;
	  
	  @MethodMetric
	  public String sendInsightFeedback(final InsightFeedbackRequest feedback) {
		 
			try {
				logger.info("Entering sendInsightFeedback() to publish feedback message to Cogscale topic: "+topic);
				if(null != feedback && null != feedback.getPayload() && null != feedback.getPayload().getData()) {
				    
					//DCC-1361 - When Kafka message is created, set META_ACTION as UPDATE 
					//and META_CREATE_DTTM as the Date time Stamp when this message was created
					DateTime dateTime = new DateTime();
					feedback.setMETA_ACTION(META_ACTION);
					feedback.setMETA_CREATE_DTTM(dateTime.toString());
					
					logger.info("Feedback Message to be published to Cogscale topic for ProfileId = "+
							  feedback.getPayload().getData().getProfileId() +" to topic: "+topic);
					MDC.put("ProfileId", feedback.getPayload().getData().getProfileId());
					
					ListenableFuture<SendResult<String, Object>> result= kafkaTemplate.send(topic, feedback); 
					
					String returnMsg = "";

					result.addCallback(new ListenableFutureCallback<SendResult<String, Object>>() {
						
			            @Override
			            public void onSuccess(SendResult<String, Object> result) {
			            	try {
								logger.info("sent message='{}'" + " to topic: {}"+" to partition={}" + " with offset={}", new ObjectMapper().writeValueAsString(feedback),
										topic,result.getRecordMetadata().partition(), result.getRecordMetadata().offset());
								MDC.put("KafkaTopicSuccessMsg", "sent message="+new ObjectMapper().writeValueAsString(feedback)+ " to topic: {}"+ topic +
										" to partition="+result.getRecordMetadata().partition()+" with offset="+ result.getRecordMetadata().offset() + " for profile id= "+
										  feedback.getPayload().getData().getProfileId());
							} catch (JsonProcessingException jsonExcep) {
								logger.error("Exception : {}",ExceptionUtils.getStackTrace(jsonExcep));
								
							}
			            }
			            @Override
			            public void onFailure(Throwable ex) {
			            	logger.error("Exception : {}",ExceptionUtils.getStackTrace(ex));
			            	if(ex instanceof KafkaProducerException) {
			            		KafkaProducerException kafkaExcep = (KafkaProducerException)ex;
			            		logger.error("KafkaProducerException on sending Feedback message..CAUSE:: {} MESSAGE:: {}",kafkaExcep.getCause(),kafkaExcep.getCause().getMessage());
			            		MDC.put("KafkaTopicErrorMsg", "KafkaProducerException on sending Feedback message..CAUSE:: {} MESSAGE:: {}"+kafkaExcep.getCause()+kafkaExcep.getCause().getMessage());

			            	}
			            	//Thread.currentThread().interrupt();
			            }
			        });
					
					kafkaTemplate.flush();
					 
				/*
				 * logger.
				 * info("Feedback Message Published successfully to Cogscale topic for ProfileId = "
				 * + feedback.getPayload().getData().getProfileId());
				 * logger.info("topic: {} payload: {}" ,topic, new
				 * ObjectMapper().writeValueAsString(feedback));
				 */
										  
					return "Feedback Message Published successfully to Cogscale topic";
					
		
				}else {
					logger.error("Error occurred in sending feedback message to Cogscale topic: "+topic+". Feedback message is invalid");
					logger.info("topic: {} payload: {}" ,topic, new ObjectMapper().writeValueAsString(feedback));
					return "Error occurred in sending feedback message to Cogscale topic: "+topic+". Feedback message is invalid";
				}
	
			  }catch(Exception e) {
				logger.error("Error occurred in sending feedback message to topic: "+topic+". Error is: "+e.getMessage());
				
				return "Error occurred in sending feedback message to Cogscale topic: "+topic+". Error is: "+e.getMessage();
	
			  }
		
		}
	 
}
