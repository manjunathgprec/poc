package com.anthem.emep.dckr.microsvc.kafkacortexconsumer.repositories;

import static com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants.ALERTS;
import static com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants.ATTRIBUTE_KEY;
import static com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants.EXPLANATIONS;
import static com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants.PROFILE_ID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.kafkacortexconsumer.utils.DateTimeFormatterUtil;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.Constants;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics.MetricConstants;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.Profile;

@Repository
public class InsightsRepository {

	@Autowired
	private MongoTemplate mongoTemplate;
	

	
	
	private static final Logger logger = LoggerFactory.getLogger(InsightsRepository.class);

	public String updateProfile(Profile profile) {
		logger.info(Constants.EXECUTE_QUERY_OF_UPDATE_PROFILE_STARTS_HERE);
		logger.info("Start Profile object update/insert to mongo db for profile id: "+profile.getProfileId());

        String crudOperation = "INSERT";
        try {
		String bckEndStartTime = DateTimeFormatterUtil.printCurrentDateTime();
		MDC.put(MetricConstants.BACKENDSTARTTIME, bckEndStartTime);
        MDC.put(MetricConstants.BACKEND, "MONGODB, DatabaseName: "+mongoTemplate.getDb().getName()+", Server: "+ mongoTemplate.getDb().getMongo().getAddress());
        
		Query query = new Query();
		query.addCriteria(Criteria.where(PROFILE_ID).is(profile.getProfileId()));
		if (profile.getInsight().getAttributeKey().startsWith(EXPLANATIONS)) {
			query.addCriteria(Criteria.where(ATTRIBUTE_KEY).is(profile.getInsight().getAttributeKey()));
		} else if (profile.getInsight().getAttributeKey().startsWith(ALERTS)) {
			query.addCriteria(Criteria.where(ATTRIBUTE_KEY).is(profile.getInsight().getAttributeKey()));
		}
		
			logger.info(Constants.EXECUTE_QUERY_OF_FETCH_PROFILE_STARTS_HERE);
			
			Profile data = mongoTemplate.findOne(query, Profile.class);
			
			logger.info(Constants.EXECUTE_QUERY_OF_FETCH_PROFILE_ENDS_HERE);

			if (!StringUtils.isEmpty(data)) {//If no data in mongo, then insert a new record, else update
				data.setProfileId(profile.getProfileId());
				data.setInsight(profile.getInsight());
				data.setTimestamp(profile.getTimestamp());
				data.setStatus(profile.getStatus());
				data.setModel_version(profile.getModel_version());
				profile = data;
				crudOperation = "UPDATE";
			}
			mongoTemplate.save(profile);
		
			MDC.put(MetricConstants.OPERATION,crudOperation);
			MDC.put(MetricConstants.OPERATIONSTATUS,MetricConstants.SUCCESS);
			MDC.put(MetricConstants.OPERATIONSTATUSCD,MetricConstants.STATUSCD_200);

			
			logger.info("Profile object "+crudOperation+" to mongo db for profile id: "+profile.getProfileId()+" is successful");
			logger.info(Constants.EXECUTE_QUERY_OF_UPDATE_PROFILE_ENDS_HERE);

			
		}catch(Exception e) {
			MDC.put(MetricConstants.OPERATION,crudOperation);
			MDC.put(MetricConstants.OPERATIONSTATUS,MetricConstants.FAILED);
			MDC.put(MetricConstants.OPERATIONERRORMSG,"Error in fetch/save to mongo db: "+e.getMessage());
			MDC.put(MetricConstants.OPERATIONSTATUSCD,MetricConstants.STATUSCD_500);
		}
		
		String bckEndEndTime = DateTimeFormatterUtil.printCurrentDateTime();
        MDC.put(MetricConstants.BACKENDENDTIME, bckEndEndTime);
        String responseTime = DateTimeFormatterUtil.totalResponseTimeInSeconds(MDC.get(MetricConstants.BACKENDSTARTTIME),bckEndEndTime);
        MDC.put(MetricConstants.JDBCWAITTIME,responseTime);

		return crudOperation;

	}

}
