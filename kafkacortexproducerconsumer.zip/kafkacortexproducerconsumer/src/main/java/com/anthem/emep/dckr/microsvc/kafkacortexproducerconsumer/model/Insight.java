
package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.data.mongodb.core.mapping.Field;

import io.swagger.annotations.ApiModelProperty;

/**
 * Insight
 */
@javax.annotation.Generated(value = "io.swagger.codegen.languages.JavaClientCodegen", date = "2019-09-26T15:33:59.696Z")
public class Insight {

  private String profileId = null;


  private String attributeKey = null;


  private AttributeValue attributeValue = null;


  private String createdAt = null;


  private String tenantId = null;


  private String environmentId = null;


  private Boolean onLatestProfile = null;


  private List<String> commits = new ArrayList<String>();

  @Field("id")
  private String id = null;


  private String version = null;


  private String classification = null;


  private String context = null;

  public Insight profileId(String profileId) {
    this.profileId = profileId;
    return this;
  }

   /**
   * Get profileId
   * @return profileId
  **/
  @ApiModelProperty(value = "")
  public String getProfileId() {
    return profileId;
  }

  public void setProfileId(String profileId) {
    this.profileId = profileId;
  }

  public Insight attributeKey(String attributeKey) {
    this.attributeKey = attributeKey;
    return this;
  }

   /**
   * Get attributeKey
   * @return attributeKey
  **/
  @ApiModelProperty(value = "")
  public String getAttributeKey() {
    return attributeKey;
  }

  public void setAttributeKey(String attributeKey) {
    this.attributeKey = attributeKey;
  }

  public Insight attributeValue(AttributeValue attributeValue) {
    this.attributeValue = attributeValue;
    return this;
  }

   /**
   * Get attributeValue
   * @return attributeValue
  **/
  @ApiModelProperty(required = true, value = "")
  public AttributeValue getAttributeValue() {
    return attributeValue;
  }

  public void setAttributeValue(AttributeValue attributeValue) {
    this.attributeValue = attributeValue;
  }

  public Insight createdAt(String createdAt) {
    this.createdAt = createdAt;
    return this;
  }

   /**
   * Get createdAt
   * @return createdAt
  **/
  @ApiModelProperty(value = "")
  public String getCreatedAt() {
    return createdAt;
  }

  public void setCreatedAt(String createdAt) {
    this.createdAt = createdAt;
  }

  public Insight tenantId(String tenantId) {
    this.tenantId = tenantId;
    return this;
  }

   /**
   * Get tenantId
   * @return tenantId
  **/
  @ApiModelProperty(value = "")
  public String getTenantId() {
    return tenantId;
  }

  public void setTenantId(String tenantId) {
    this.tenantId = tenantId;
  }

  public Insight environmentId(String environmentId) {
    this.environmentId = environmentId;
    return this;
  }

   /**
   * Get environmentId
   * @return environmentId
  **/
  @ApiModelProperty(value = "")
  public String getEnvironmentId() {
    return environmentId;
  }

  public void setEnvironmentId(String environmentId) {
    this.environmentId = environmentId;
  }

  public Insight onLatestProfile(Boolean onLatestProfile) {
    this.onLatestProfile = onLatestProfile;
    return this;
  }

   /**
   * Get onLatestProfile
   * @return onLatestProfile
  **/
  @ApiModelProperty(value = "")
  public Boolean isOnLatestProfile() {
    return onLatestProfile;
  }

  public void setOnLatestProfile(Boolean onLatestProfile) {
    this.onLatestProfile = onLatestProfile;
  }

  public Insight commits(List<String> commits) {
    this.commits = commits;
    return this;
  }

  public Insight addCommitsItem(String commitsItem) {
    this.commits.add(commitsItem);
    return this;
  }

   /**
   * Get commits
   * @return commits
  **/
  @ApiModelProperty(required = true, value = "")
  public List<String> getCommits() {
    return commits;
  }

  public void setCommits(List<String> commits) {
    this.commits = commits;
  }

  public Insight id(String id) {
    this.id = id;
    return this;
  }

   /**
   * Get id
   * @return id
  **/
  @ApiModelProperty(value = "")
  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public Insight version(String version) {
    this.version = version;
    return this;
  }

   /**
   * Get version
   * @return version
  **/
  @ApiModelProperty(value = "")
  public String getVersion() {
    return version;
  }

  public void setVersion(String version) {
    this.version = version;
  }

  public Insight classification(String classification) {
    this.classification = classification;
    return this;
  }

   /**
   * Get classification
   * @return classification
  **/
  @ApiModelProperty(value = "")
  public String getClassification() {
    return classification;
  }

  public void setClassification(String classification) {
    this.classification = classification;
  }

  public Insight context(String context) {
    this.context = context;
    return this;
  }

   /**
   * Get context
   * @return context
  **/
  @ApiModelProperty(value = "")
  public String getContext() {
    return context;
  }

  public void setContext(String context) {
    this.context = context;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Insight insight = (Insight) o;
    return Objects.equals(this.profileId, insight.profileId) &&
        Objects.equals(this.attributeKey, insight.attributeKey) &&
        Objects.equals(this.attributeValue, insight.attributeValue) &&
        Objects.equals(this.createdAt, insight.createdAt) &&
        Objects.equals(this.tenantId, insight.tenantId) &&
        Objects.equals(this.environmentId, insight.environmentId) &&
        Objects.equals(this.onLatestProfile, insight.onLatestProfile) &&
        Objects.equals(this.commits, insight.commits) &&
        Objects.equals(this.id, insight.id) &&
        Objects.equals(this.version, insight.version) &&
        Objects.equals(this.classification, insight.classification) &&
        Objects.equals(this.context, insight.context);
  }

  @Override
  public int hashCode() {
    return Objects.hash(profileId, attributeKey, attributeValue, createdAt, tenantId, environmentId, onLatestProfile, commits, id, version, classification, context);
  }


  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Insight {\n");
    
    sb.append("    profileId: ").append(toIndentedString(profileId)).append("\n");
    sb.append("    attributeKey: ").append(toIndentedString(attributeKey)).append("\n");
    sb.append("    attributeValue: ").append(toIndentedString(attributeValue)).append("\n");
    sb.append("    createdAt: ").append(toIndentedString(createdAt)).append("\n");
    sb.append("    tenantId: ").append(toIndentedString(tenantId)).append("\n");
    sb.append("    environmentId: ").append(toIndentedString(environmentId)).append("\n");
    sb.append("    onLatestProfile: ").append(toIndentedString(onLatestProfile)).append("\n");
    sb.append("    commits: ").append(toIndentedString(commits)).append("\n");
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    classification: ").append(toIndentedString(classification)).append("\n");
    sb.append("    context: ").append(toIndentedString(context)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }

}
