package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer;

public class Constants {
	
	public static final String GET_PROFILE="/profile";
	public static final String INSIGHT = "/insight";
	public static final String FEEDBACK="/feedback";
	public static final String BASEPATH="kafka/publish";
	public static final String INSIGHTFEEDBACK="/insight/feedback";
	public static final String PROFILE_ID="profileId";
	public static final String ATTRIBUTE_KEY="insight.attributeKey";
	public static final String INSIGHT_ID="insight.attributeValue.value.body.explanations_value.insightId";
	public static final String ALERTS="alerts";
	public static final String EXPLANATIONS="explanations_";
	public static final String PROFILE_NOT_FOUND="Profile not found for profileId =";
	public static final String PROVIDED_CLAIMID="Provided claimId ";
	public static final String INVALID =" is invalid";
	public static final String INVALID_PROFILE="Invalid ProfileId";
	public static final String EXCEPTION_CODE_1002="1002";
	public static final String EXPLANATIONS_VALUE="explanations_value";
	public static final String ALERTS_VALUE="alerts_value";
	public static final String SHOW_MATH="show_math_value";
	
	public static final String META_ACTION="UPDATE";
	
	public static final String REST_TRANSACTION = "Rest Transaction: Entering sendInsightFeedBackToCogScale() --- **Start time ** ";

	public static final String ENTERING_FEEDBACK_CONTROLLER = "Entering FeedbackAPIController";

	public static final String EXITING_FEEDBACK_CONTROLLER_TIME_TAKEN = "Exiting FeedbackAPIController <> time taken <>";
	
	public static final String EXECUTE_QUERY_OF_UPDATE_PROFILE_ENDS_HERE = "updateProfile() of InsightsRepository ends here.";

	public static final String EXECUTE_QUERY_OF_UPDATE_PROFILE_STARTS_HERE = "updateProfile() of InsightsRepository starts here.";
	
	public static final String EXECUTE_QUERY_OF_FETCH_PROFILE_STARTS_HERE = "Inside updateProfile(), fetching insights from mongo starts here.";
	public static final String EXECUTE_QUERY_OF_FETCH_PROFILE_ENDS_HERE = "Inside updateProfile(), fetching insights from mongo ends here.";

	public static final String MONGO_DB_ECOMM_URI = "mongo.datasource.ecommdb.uri";
	
}
