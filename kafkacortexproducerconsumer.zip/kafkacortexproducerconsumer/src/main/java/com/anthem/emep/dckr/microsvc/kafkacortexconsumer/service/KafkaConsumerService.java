package com.anthem.emep.dckr.microsvc.kafkacortexconsumer.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics.MethodMetric;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.metrics.MetricConstants;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.Profile;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.anthem.emep.dckr.microsvc.kafkacortexconsumer.repositories.InsightsRepository;
import com.anthem.emep.dckr.microsvc.kafkacortexconsumer.utils.JSONUtils;

@Service
public class KafkaConsumerService {
	
	private static final Logger logger = LoggerFactory.getLogger(KafkaConsumerService.class);
	
	@Autowired
	private InsightsRepository insightsRepo;
	
	@Autowired
	private ObjectMapper objectMapper;

	@KafkaListener(topics = {"${applicationProperties.kafkaconsumerpropmap.kafka.serviceExp.topic}"})
	@Retryable(maxAttemptsExpression = "${maxAttempts}" , backoff = @Backoff(delayExpression = "${delay}" , maxDelayExpression = "${maxDelay}" , multiplierExpression = "${multiplier}" ))
	@MethodMetric
	public void onMessage(ConsumerRecord<String, Object> record){
		
		logger.info("Message received from kafka topic: ");
		Profile profileObject = null;
		String profileId = "";
		try {
			if(null != record) {
				MDC.put(MetricConstants.TOPIC, record.topic());
				MDC.put(MetricConstants.TOPICOFFSET, String.valueOf(record.offset()));
				MDC.put(MetricConstants.TOPICPARTITION, String.valueOf(record.partition()));
				
				if(null != record.value()) {
					logger.info("Message payload: {}" , record.value());
					String payload = objectMapper.writeValueAsString(record.value());//Convert object to string
					logger.info("String payload: {}" , payload);
					if(JSONUtils.isJSONValid(payload)) {//check if the message is valid json.
						profileObject = objectMapper.readValue(payload, Profile.class);//Create Profile object from string payload
						 logger.info("Profile object payload: {}" , profileObject);
						if(null != profileObject && profileObject instanceof Profile) {
							profileId = profileObject.getProfileId();	
							if(!StringUtils.isEmpty(profileId)) {
								MDC.put(MetricConstants.PROFILEID, profileId);
								logger.info("Message consumed with profileId: " + profileId);
								String status = insightsRepo.updateProfile(profileObject);
								MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.SUCCESS);
			        	        MDC.put(MetricConstants.STATUSCD, MetricConstants.STATUSCD_200);
								logger.info("Message got updated/inserted in mongo db for "+profileId+" and got "+status);
							}else {
								MDC.put(MetricConstants.ERRORMSG,"Empty profile id received from the topic.");
								MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.FAILED);
								MDC.put(MetricConstants.STATUSCD, MetricConstants.STATUSCD_400);				
							}
						}else {
							MDC.put(MetricConstants.ERRORMSG,"Invalid JSON message received from the topic.");
							MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.FAILED);
							MDC.put(MetricConstants.STATUSCD,MetricConstants.STATUSCD_400);				
						}
					}else {
						MDC.put(MetricConstants.ERRORMSG,"Invalid JSON message received from the topic.");
						MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.FAILED);
						MDC.put(MetricConstants.STATUSCD, MetricConstants.STATUSCD_400);				

					}
				}else {
					MDC.put(MetricConstants.ERRORMSG,"Empty message received from the topic.");
					MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.FAILED);
					MDC.put(MetricConstants.STATUSCD, MetricConstants.STATUSCD_400);				
				}
			}else {
				MDC.put(MetricConstants.ERRORMSG,"Empty message received from the topic.");
				MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.FAILED);
				MDC.put(MetricConstants.STATUSCD, MetricConstants.STATUSCD_400);				
			} 
			
		}catch(Exception e) {
			MDC.put(MetricConstants.ERRORMSG,"Error occurred while receiving message from topic: "+e.getMessage());
			MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.FAILED);
			MDC.put(MetricConstants.STATUSCD, MetricConstants.STATUSCD_400);
	
		}

	}

	
}
