package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.Body;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.ExplanationsValue;

public class BodyTest {
	
	private static final String insightId = "insightId";
	private static final String insightKey = "insightKey";
	private static final String insight = "insight";
	private static final Double score = 0.0;
	
	Body body = new Body();

	@Test
	public void mustStoreAndRetrieveValueFromTheFieldExplantionsValue() {
		// given
		List<ExplanationsValue> evListToSet= new ArrayList<ExplanationsValue>();
		ExplanationsValue ev = new ExplanationsValue();
		
		ev.setInsight(insight);
		ev.setInsightId(insightId);
		ev.setInsightKey(insightKey);
		ev.setScore(score);
		evListToSet.add(ev);
		
		body.setExplanationsValue(evListToSet);
		//when
		List<ExplanationsValue> evListFromGet=body.getExplanationsValue();

		// then
		assertEquals(evListFromGet, evListToSet);
	}

}
