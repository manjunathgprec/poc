package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model;

import static org.junit.Assert.*;

import org.junit.Test;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.ExplanationsValue;

public class ExplanationsValueTest {

	private static final String insightId = "insightId";
	private static final String insightKey = "insightKey";
	private static final String insight = "insight";
	private static final Double score = 0.0;

	private ExplanationsValue explanationsValue = new ExplanationsValue();

	@Test
	public void mustStoreAndRetrieveValueFromTheFieldInsightId() {
		// given
		String insightIdToSet = insightId;
		explanationsValue.setInsightId(insightIdToSet);
		// when
		String insightIdFromGet = explanationsValue.getInsightId();
		// then
		assertEquals(insightIdFromGet, insightIdToSet);
	}

	@Test
	public void mustStoreAndRetrieveValueFromTheFieldInsight() {
		// given
		String insightToSet = insight;
		explanationsValue.setInsight(insightToSet);
		// when
		String insightFromGet = explanationsValue.getInsight();
		// then
		assertEquals(insightFromGet, insightToSet);
	}

	@Test
	public void mustStoreAndRetrieveValueFromTheFieldInsightKey() {
		// given
		String insightKeyToSet = insightKey;
		explanationsValue.setInsightKey(insightKeyToSet);
		// when
		String insightKeyFromGet = explanationsValue.getInsightKey();
		// then
		assertEquals(insightKeyFromGet, insightKeyToSet);
	}

	public void mustStoreAndRetrieveValueFromTheFieldScore() {
		// given
		Double scoreToSet = score;
		explanationsValue.setScore(scoreToSet);
		// when
		Double scoreFromGet = explanationsValue.getScore();
		// then
		assertEquals(scoreFromGet, scoreToSet);
	}

}
