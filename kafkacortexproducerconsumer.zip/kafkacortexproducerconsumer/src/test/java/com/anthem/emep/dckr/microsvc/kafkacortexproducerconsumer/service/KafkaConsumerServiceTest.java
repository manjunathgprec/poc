package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.anthem.emep.dckr.microsvc.kafkacortexconsumer.repositories.InsightsRepository;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.ApplicationTest;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.config.KafkaConfig;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.Profile;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mongodb.MongoClientURI;


@RunWith(SpringJUnit4ClassRunner.class)
//@SpringBootTest(classes = ApplicationTest.class)
//@ContextConfiguration(classes = ApplicationTest.class)
public class KafkaConsumerServiceTest {

	
	
	
	  //@Autowired private InsightsRepository insightsRepo;
	 
	
	
	  @InjectMocks private InsightsRepository insightsRepo;
	  
	  @Mock private MongoTemplate mongoTemplate;
	 
	 
	

	Profile profileUpdateAlerts = null;
	Profile profileUpdateClaims = null;

	Profile profileInsert = null;

	
	
	  @Before public void init() { MockitoAnnotations.initMocks(this); }
	 
	
	
	@Before
	public void setUp() throws JsonParseException, JsonMappingException, IOException {
		
		
		String producerMessageUpdateAlerts = "{\r\n" + 
		 		"    \"insight\" : {\r\n" + 
		 		"        \"profileId\" : \"CSPFE16LIES1QROMW\",\r\n" + 
		 		"        \"attributeKey\" : \"alerts_OON_eed0d7d1-b199-499d-84ef-11fe0c1a5f2a\",\r\n" + 
		 		"        \"attributeValue\" : {\r\n" + 
		 		"            \"value\" : {\r\n" + 
		 		"                \"id\" : \"3591190e-140e-4da4-87f6-744341145158\",\r\n" + 
		 		"                \"insightType\" : \"Alerts OON 2019113MC4400\",\r\n" + 
		 		"                \"profileId\" : \"CSPFE16LIES1QROMW\",\r\n" + 
		 		"                \"dateGeneratedUTCISO\" : \"2019-10-17T20:54:35.553714+00:00\",\r\n" + 
		 		"                \"appId\" : \"Anthem:v1\",\r\n" + 
		 		"                \"tags\" : [],\r\n" + 
		 		"                \"body\" : {\r\n" + 
		 		"                    \"alerts_value\" : [ \r\n" + 
		 		"                        {\r\n" + 
		 		"                            \"insightId\" : \"eed0d7d1-b199-499d-84ef-11fe0c1a5f2a\",\r\n" + 
		 		"                            \"insight\" : \"In looking at your plan, I noticed you recently received services from an out of network doctor. MIRIAM G ADLER PC         on 2019-04-08 (thumbs up/ thumbs down)\\nTo get the most value out of your plan you should always choose doctors in your network.\\nWould you like for me to help you do that? Or would like to review the claim?\",\r\n" + 
		 		"                            \"score\" : 0.318939624261869,\r\n" + 
		 		"                            \"viewed\" : true,\r\n" + 
		 		"                            \"feedback\" : \"Accepted\"\r\n" + 
		 		"                        }\r\n" + 
		 		"                    ]\r\n" + 
		 		"                },\r\n" + 
		 		"                \"context\" : \"cortex/insight\",\r\n" + 
		 		"                \"version\" : \"0.0.1\"\r\n" + 
		 		"            },\r\n" + 
		 		"            \"context\" : \"cortex/attribute-value-insight\",\r\n" + 
		 		"            \"version\" : \"0.0.1\",\r\n" + 
		 		"            \"summary\" : \"Insight<type=Alerts OON 2019113MC4400,id=3591190e-140e-4da4-87f6-744341145158>\\\"\"\r\n" + 
		 		"        },\r\n" + 
		 		"        \"createdAt\" : \"2019-10-17T20:59:38.730418+00:00\",\r\n" + 
		 		"        \"tenantId\" : \"anthemorg\",\r\n" + 
		 		"        \"environmentId\" : \"cortex/default\",\r\n" + 
		 		"        \"onLatestProfile\" : true,\r\n" + 
		 		"        \"commits\" : [],\r\n" + 
		 		"        \"id\" : \"aab1c9e1-5e22-4c4c-a45b-37a8b3bc4ab3\",\r\n" + 
		 		"        \"version\" : \"0.0.1\",\r\n" + 
		 		"        \"classification\" : \"observed\",\r\n" + 
		 		"        \"context\" : \"cortex/attributes-observed\"\r\n" + 
		 		"    },\r\n" + 
		 		"    \"model_version\" : \"xt00cy4\",\r\n" + 
		 		"    \"profileId\" : \"CSPFE16LIES1QROMW\",\r\n" + 
		 		"    \"status\" : \"NEW1\",\r\n" + 
		 		"    \"timestamp\" : \"2019-10-17T20:59:38.730535+00:00\"\r\n" + 
		 		"}\r\n"; 
		 		
		 ObjectMapper mapper1 = new ObjectMapper();
		 profileUpdateAlerts = mapper1.readValue(producerMessageUpdateAlerts, Profile.class);
		
		 
		 String producerMessageUpdateClaims = "{\r\n" + 
		 		"   \"insight\": {\r\n" + 
		 		"		\"profileId\": \"CSPDE16M7DUOMXM7N\",\r\n" + 
		 		"		\"attributeKey\": \"explanations_2019051CM4761\",\r\n" + 
		 		"		\"attributeValue\": {\r\n" + 
		 		"			\"value\": {\r\n" + 
		 		"				\"id\": \"9ccaa70c-006d-4ac5-a42e-bb1846a48943\",\r\n" + 
		 		"				\"insightType\": \"Claim Explanations\",\r\n" + 
		 		"				\"profileId\": \"CSPDE16M7DUOMXM7N\",\r\n" + 
		 		"				\"dateGeneratedUTCISO\": \"2019-08-16T06:46:35.822659+00:00\",\r\n" + 
		 		"				\"appId\": \"Anthem:v1\",\r\n" + 
		 		"				\"tags\": [],\r\n" + 
		 		"				\"body\": {\r\n" + 
		 		"					\"explanations_value\": [\r\n" + 
		 		"						{\r\n" + 
		 		"							\"insightId\": \"23b8101d-fdfe-45c4-aa52-314ff79e321e\",\r\n" + 
		 		"							\"insightKey\": \"3d8b51b3-e352-4ccc-81e8-012169adaf68\",\r\n" + 
		 		"							\"insight\": \"1\",\r\n" + 
		 		"							\"score\": 0.479202729702026,\r\n" + 
		 		"							\"order\": 0,\r\n" + 
		 		"							\"channel\": \"SELF_SERVE\",\r\n" + 
		 		"							\"feedback\": \"\",\r\n" + 
		 		"							\"eob\": [\r\n" + 
		 		"								\"00066\"\r\n" + 
		 		"							],\r\n" + 
		 		"							\"summary\": [\r\n" + 
		 		"								\"Doctors in your plan accept our discount for their services. The remaining balance after Anthem's discount is applied is the amount your doctor gets paid by you or Anthem.\"\r\n" + 
		 		"							]\r\n" + 
		 		"						},\r\n" + 
		 		"						{\r\n" + 
		 		"							\"insightId\": \"279f6548-c542-4d8d-908b-959c5ce891b7\",\r\n" + 
		 		"							\"insightKey\": \"0205bd55-97fc-4ece-8693-5499b9420089\",\r\n" + 
		 		"							\"insight\": \"1\",\r\n" + 
		 		"							\"score\": 0.479202729702026,\r\n" + 
		 		"							\"order\": 0,\r\n" + 
		 		"							\"channel\": \"AGENT_ASSIST\",\r\n" + 
		 		"							\"feedback\": \"\",\r\n" + 
		 		"							\"eob\": [\r\n" + 
		 		"								\"00066\"\r\n" + 
		 		"							],\r\n" + 
		 		"							\"summary\": [\r\n" + 
		 		"								\"All of our in-network professional providers accept our discount which means your total responsibility will not be more than the amount Anthem allows.\\n \\nIf your <doctor or facility> is asking for reimbursement up their charge amount instead of our network discount (maximum allowable), please let me call them to ensure that they know the correct amount they should be billing you.\"\r\n" + 
		 		"							]\r\n" + 
		 		"						},\r\n" + 
		 		"						{\r\n" + 
		 		"							\"insightId\": \"6c6ed533-9233-41d9-bafd-bd27ba281bd3\",\r\n" + 
		 		"							\"insightKey\": \"94fcc1ac-3558-409c-b595-0c08b2ec19fa\",\r\n" + 
		 		"							\"insight\": \"2\",\r\n" + 
		 		"							\"score\": 0.479202729702026,\r\n" + 
		 		"							\"order\": 1,\r\n" + 
		 		"							\"channel\": \"SELF_SERVE\",\r\n" + 
		 		"							\"feedback\": \"\",\r\n" + 
		 		"							\"eob\": [\r\n" + 
		 		"								\"00066\"\r\n" + 
		 		"							],\r\n" + 
		 		"							\"summary\": [\r\n" + 
		 		"								\"Doctors in your plan accept our discount for their services. The remaining balance after Anthem's discount is applied is the amount your doctor gets paid by you or Anthem.\"\r\n" + 
		 		"							]\r\n" + 
		 		"						},\r\n" + 
		 		"						{\r\n" + 
		 		"							\"insightId\": \"d337a60a-0614-48e6-80cc-e0b786faf421\",\r\n" + 
		 		"							\"insightKey\": \"5e32a019-f989-47be-b7c8-bed9ea5e8e70\",\r\n" + 
		 		"							\"insight\": \"2\",\r\n" + 
		 		"							\"score\": 0.479202729702026,\r\n" + 
		 		"							\"order\": 1,\r\n" + 
		 		"							\"channel\": \"AGENT_ASSIST\",\r\n" + 
		 		"							\"feedback\": \"\",\r\n" + 
		 		"							\"eob\": [\r\n" + 
		 		"								\"00066\"\r\n" + 
		 		"							],\r\n" + 
		 		"							\"summary\": [\r\n" + 
		 		"								\"All of our in-network professional providers accept our discount which means your total responsibility will not be more than the amount Anthem allows.\\n \\nIf your <doctor or facility> is asking for reimbursement up their charge amount instead of our network discount (maximum allowable), please let me call them to ensure that they know the correct amount they should be billing you.\"\r\n" + 
		 		"							]\r\n" + 
		 		"						}\r\n" + 
		 		"					],\r\n" + 
		 		"					\"show_math_value\": \"What the provider charged: 483.00\\nWhat Anthem allowed:  20.80\\nWhat Anthem paid: 16.64\\nIn-Network discount: 462.2 \\nWhat the member owes: 4.16\\nDeductible amount: 0.00\\nCoinsurance amount: 4.16\\nCopayment amount: 0.00\\nNon-eligible charges: 0.00\\nWhat Medicare allowed: 0.00\\nWhat Medicare paid: 0.00\"\r\n" + 
		 		"				},\r\n" + 
		 		"				\"context\": \"cortex/insight\",\r\n" + 
		 		"				\"version\": \"0.0.1\"\r\n" + 
		 		"			},\r\n" + 
		 		"			\"context\": \"cortex/attribute-value-insight\",\r\n" + 
		 		"			\"version\": \"0.0.1\",\r\n" + 
		 		"			\"summary\": \"Insight<type=Claim Explanations,id=9ccaa70c-006d-4ac5-a42e-bb1846a48943>\\\"\"\r\n" + 
		 		"		},\r\n" + 
		 		"		\"createdAt\": \"2019-08-16T14:47:36.639219+00:00\",\r\n" + 
		 		"		\"tenantId\": null,\r\n" + 
		 		"		\"environmentId\": null,\r\n" + 
		 		"		\"onLatestProfile\": true,\r\n" + 
		 		"		\"commits\": [],\r\n" + 
		 		"		\"id\": \"1104fef9-a761-4fb8-8324-3a6ae90f6ec1\",\r\n" + 
		 		"		\"version\": \"0.0.1\",\r\n" + 
		 		"		\"classification\": \"declared\",\r\n" + 
		 		"		\"context\": \"cortex/attributes-declared\"\r\n" + 
		 		"	},\r\n" + 
		 		"    \"model_version\" : \"xt00cy4\",\r\n" + 
		 		"    \"profileId\" : \"CSPDE16M7DUOMXM7N\",\r\n" + 
		 		"    \"status\" : \"NEW1\",\r\n" + 
		 		"    \"timestamp\" : \"2019-10-03T20:59:38.730535+00:00\"\r\n" + 
		 		"}\r\n" + 
		 		"";
		 
		 ObjectMapper mapper2 = new ObjectMapper();
		 profileUpdateClaims = mapper2.readValue(producerMessageUpdateClaims, Profile.class);
		
		 
		 String producerMessageInsert = "{\r\n" + 
		 		"    \"insight\" : {\r\n" + 
		 		"        \"profileId\" : \"CSPFE16LIES1QREDS\",\r\n" + 
		 		"        \"attributeKey\" : \"alerts_OON_wwd0d7d1-b199-499d-84ef-11fe0c1456fab\",\r\n" + 
		 		"        \"attributeValue\" : {\r\n" + 
		 		"            \"value\" : {\r\n" + 
		 		"                \"id\" : \"3591190e-140e-4da4-87f6-744341145158\",\r\n" + 
		 		"                \"insightType\" : \"Alerts OON 2019113MC4411\",\r\n" + 
		 		"                \"profileId\" : \"CSPFE16LIES1QREDS\",\r\n" + 
		 		"                \"dateGeneratedUTCISO\" : \"2019-10-17T20:54:35.553714+00:00\",\r\n" + 
		 		"                \"appId\" : \"Anthem:v1\",\r\n" + 
		 		"                \"tags\" : [],\r\n" + 
		 		"                \"body\" : {\r\n" + 
		 		"                    \"alerts_value\" : [ \r\n" + 
		 		"                        {\r\n" + 
		 		"                            \"insightId\" : \"eed0d7d1-b199-499d-84ef-11fe0c1a5f2a\",\r\n" + 
		 		"                            \"insight\" : \"In looking at your plan, I noticed you recently received services from an out of network doctor. MIRIAM G ADLER PC         on 2019-04-08 (thumbs up/ thumbs down)\\nTo get the most value out of your plan you should always choose doctors in your network.\\nWould you like for me to help you do that? Or would like to review the claim?\",\r\n" + 
		 		"                            \"score\" : 0.318939624261869,\r\n" + 
		 		"                            \"viewed\" : true,\r\n" + 
		 		"                            \"feedback\" : \"Accepted\"\r\n" + 
		 		"                        }\r\n" + 
		 		"                    ]\r\n" + 
		 		"                },\r\n" + 
		 		"                \"context\" : \"cortex/insight\",\r\n" + 
		 		"                \"version\" : \"0.0.1\"\r\n" + 
		 		"            },\r\n" + 
		 		"            \"context\" : \"cortex/attribute-value-insight\",\r\n" + 
		 		"            \"version\" : \"0.0.1\",\r\n" + 
		 		"            \"summary\" : \"Insight<type=Alerts OON 2019113MC4400,id=3591190e-140e-4da4-87f6-744341145158>\\\"\"\r\n" + 
		 		"        },\r\n" + 
		 		"        \"createdAt\" : \"2019-10-17T20:59:38.730418+00:00\",\r\n" + 
		 		"        \"tenantId\" : \"anthemorg\",\r\n" + 
		 		"        \"environmentId\" : \"cortex/default\",\r\n" + 
		 		"        \"onLatestProfile\" : true,\r\n" + 
		 		"        \"commits\" : [],\r\n" + 
		 		"        \"id\" : \"aab1c9e1-5e22-4c4c-a45b-37a8b3bc4ab3\",\r\n" + 
		 		"        \"version\" : \"0.0.1\",\r\n" + 
		 		"        \"classification\" : \"observed\",\r\n" + 
		 		"        \"context\" : \"cortex/attributes-observed\"\r\n" + 
		 		"    },\r\n" + 
		 		"    \"model_version\" : \"xt00cy4\",\r\n" + 
		 		"    \"profileId\" : \"CSPFE16LIES1QREDS\",\r\n" + 
		 		"    \"status\" : \"NEW\",\r\n" + 
		 		"    \"timestamp\" : \"2019-12-03T20:59:38.730535+00:00\"\r\n" + 
		 		"}\r\n" + 
		 		"";
		 
		 ObjectMapper mapper3 = new ObjectMapper();
		 profileInsert = mapper3.readValue(producerMessageInsert, Profile.class);
		

	}
	
	@Test
	public void updateProfileTestUpdateAlerts() {
		/*
		 * ConsumerRecord<String, Object> singleRecord = new ConsumerRecord<String,
		 * Object>("testtopic", 0, 45, "update-test-alerts", profileUpdateAlerts);
		 * 
		 * assertThat(singleRecord).isNotNull();
		 * assertThat(singleRecord.key()).isEqualTo("update-test-alerts");
		 * assertThat(singleRecord.value()).isEqualTo(profileUpdateAlerts);
		 * assertThat("success".equalsIgnoreCase(service.onMessage(singleRecord)));
		 */
		
	
       // when(insightsRepo.updateProfile(profileUpdateAlerts)).thenReturn("success");
        //verify(insightsRepo, times(1)).updateProfile(profileUpdateAlerts);
		
		assertThat("success".equalsIgnoreCase(insightsRepo.updateProfile(profileUpdateAlerts)));
		
	}

	
	@Test
	public void updateProfileTestUpdateClaims() {

		/*
		 * ConsumerRecord<String, Object> singleRecord = new ConsumerRecord<String,
		 * Object>("testtopic", 0, 45, "update-test-claims", profileUpdateClaims);
		 * 
		 * assertThat(singleRecord).isNotNull();
		 * assertThat(singleRecord.key()).isEqualTo("update-test-claims");
		 * assertThat(singleRecord.value()).isEqualTo(profileUpdateClaims);
		 * assertThat("success".equalsIgnoreCase(service.onMessage(singleRecord)));
		 */
		assertThat("success".equalsIgnoreCase(insightsRepo.updateProfile(profileUpdateClaims)));
		/*
		 * when(insightsRepo.updateProfile(profileUpdateClaims)).thenReturn("success");
		 * verify(insightsRepo, times(1)).updateProfile(profileUpdateClaims);
		 */

	}
	
	@Test
	public void updateProfileTestInsert() {
		
		/*
		 * ConsumerRecord<String, Object> singleRecord = new ConsumerRecord<String,
		 * Object>("testtopic", 0, 45, "insert-test-record", profileInsert);
		 * 
		 * assertThat(singleRecord).isNotNull();
		 * assertThat(singleRecord.key()).isEqualTo("insert-test-record");
		 * assertThat(singleRecord.value()).isEqualTo(profileInsert);
		 * assertThat("success".equalsIgnoreCase(service.onMessage(singleRecord)));
		 */
		
		assertThat("success".equalsIgnoreCase(insightsRepo.updateProfile(profileInsert)));
		/*
		 * when(insightsRepo.updateProfile(profileInsert)).thenReturn("success");
		 * verify(insightsRepo, times(1)).updateProfile(profileInsert);
		 */

		
	}
	
	
	

}
