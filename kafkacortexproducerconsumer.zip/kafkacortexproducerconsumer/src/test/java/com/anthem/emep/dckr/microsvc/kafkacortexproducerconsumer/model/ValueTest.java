package com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.Body;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.ExplanationsValue;
import com.anthem.emep.dckr.microsvc.kafkacortexproducerconsumer.model.Value;

public class ValueTest {
	
	Value value = new Value();

	@Test
	public void mustStoreAndRetrieveValueFromTheFielBody() {
		List<ExplanationsValue> evList= new ArrayList<ExplanationsValue>();
		ExplanationsValue ev = new ExplanationsValue();
		
		ev.setInsight("insight");
		ev.setInsightId("insightId");
		ev.setInsightKey("insightKey");
		ev.setScore(0.0);
		evList.add(ev);
		
		Body bodyToSet = new Body();
		bodyToSet.setExplanationsValue(evList);
		value.setBody(bodyToSet);
		
		Body bodyFromGet = value.getBody();
		
		// then
		assertEquals(bodyFromGet, bodyToSet);
		
		
		
	}

}
