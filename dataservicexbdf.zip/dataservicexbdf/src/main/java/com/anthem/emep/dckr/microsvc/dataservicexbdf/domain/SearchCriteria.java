package com.anthem.emep.dckr.microsvc.dataservicexbdf.domain;

import org.springframework.jdbc.core.RowMapper;

public class SearchCriteria {

	private int pageSize;
	private String sqlCountRows;
	private String sqlFetchRows;
	private String startDate;
	private String endDate;
	private RowMapper mapper;
	private String tableName;

	public RowMapper getMapper() {
		return mapper;
	}

	public void setMapper(RowMapper mapper) {
		this.mapper = mapper;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getSqlCountRows() {
		return sqlCountRows;
	}

	public void setSqlCountRows(String sqlCountRows) {
		this.sqlCountRows = sqlCountRows;
	}

	public String getSqlFetchRows() {
		return sqlFetchRows;
	}

	public void setSqlFetchRows(String sqlFetchRows) {
		this.sqlFetchRows = sqlFetchRows;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

}
