package com.anthem.emep.dckr.microsvc.dataservicexbdf.service.kafka;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaProducerException;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.ApplicationPropertyConfig;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.Page;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.metrics.MethodMetric;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.PersonProxyRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.PersonProxyRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.ApplicationConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class provides interface for publishing messages over Kafka topic
 * 
 * @author AG59866
 *
 */
@Service
public class KafkaPublishService {

	Logger logger = LoggerFactory.getLogger(KafkaPublishService.class);

	@Autowired
	private ApplicationPropertyConfig config;

	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;
	
	@Autowired
	private PersonProxyRecordsRepository ehubPrsnProxyRltnshpRepository;
	
	private boolean isObjectModified(BaseEntity data) {
		boolean isConentChanged = false;
		if (data instanceof PersonProxyRecords) {
			PersonProxyRecords entity = (PersonProxyRecords) data;
			isConentChanged = ehubPrsnProxyRltnshpRepository.isDataModified(entity);
		}
		return isConentChanged;
		
	}

	public void sendMessage(Page<BaseEntity> page, String tableName) {

		String topicName = config.getKafkaproducerpropmap().get(ApplicationConstants.KAFKA_TOPIC_NAME);

		for (int index = 0; index < page.getPageItems().size(); index++) { 
			BaseEntity data = page.getPageItems().get(index);
			
//			if(isObjectModified(data)) {
//				continue;
//			}

			List<Header> headers = new ArrayList<>();
			headers.add(new RecordHeader("META_PO_MSG_TYPE", data.getMetaMsgType().getBytes()));

			String kafkaKey = data.getMetaMsgType() + "" + data.getMetaRecLtstUpdtGuid();

			try {
				ProducerRecord<String, String> record = new ProducerRecord<>(topicName, 0, kafkaKey,
						new ObjectMapper().writeValueAsString(data), headers);
				System.out.println(new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(data));
				ListenableFuture<SendResult<String, String>> result = kafkaTemplate.send(record);

				result.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

					@Override
					@MethodMetric
					public void onSuccess(SendResult<String, String> result) {
//						MDC.put("Sample","Test");
						logger.info(
								"sent message from table : {}" + " guid: {}" + " msg created date: {} "
										+ " to topic: {}" + " to partition={}" + " with offset={}",
								tableName, data.getMetaRecLtstUpdtGuid(), data.getMetaMsgCreateDtm(), topicName,
								result.getRecordMetadata().partition(), result.getRecordMetadata().offset());
						MDC.put("KafkaTopicSuccessMsg", "sent message from table="+ tableName+  " guid:" +data.getMetaRecLtstUpdtGuid()+ " msg created date: " +  data.getMetaMsgCreateDtm() +
								 " to topic: {}"+ topicName +
								" to partition="+result.getRecordMetadata().partition()+" with offset="+ result.getRecordMetadata().offset());
					}

					@Override
					public void onFailure(Throwable ex) {
						logger.error("Exception : {}", ExceptionUtils.getStackTrace(ex));
						if (ex instanceof KafkaProducerException) {
							KafkaProducerException kafkaExcep = (KafkaProducerException) ex;
							logger.error(
									"KafkaProducerException on sending dataservicexbdf message..CAUSE:: {} MESSAGE:: {}",
									kafkaExcep.getCause(), kafkaExcep.getCause().getMessage());
						}
					}
				});

				kafkaTemplate.flush();
			} catch (Exception e) {
				logger.error("Error occurred in sending dataservicexbdf message to topic: " + topicName + ". Error is: "
						+ e.getMessage());
			}

		}

	}

}
