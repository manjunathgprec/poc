package com.anthem.emep.dckr.microsvc.dataservicexbdf.domain;

public class LastProcessedDate {

	private String personProxyRecordsStartDate;
	private String memberCaseRecordsStartDate;
	private String membershipRecordsStartDate;
	private String memberNetworkRecordsStartDate;
	private String claimSummaryRecordsStartDate;
	private String claimLineDetailRecordsStartDate;
	private String claimLineEOBRecordsStartDate;
	private String claimPaymentRecordsStartDate;
	private String claimEOBLookupRecordsStartDate;
	private String claimInquiryRecordsStartDate;

	public String getPersonProxyRecordsStartDate() {
		return personProxyRecordsStartDate;
	}

	public void setPersonProxyRecordsStartDate(String personProxyRecordsStartDate) {
		this.personProxyRecordsStartDate = personProxyRecordsStartDate;
	}

	public String getMemberCaseRecordsStartDate() {
		return memberCaseRecordsStartDate;
	}

	public void setMemberCaseRecordsStartDate(String memberCaseRecordsStartDate) {
		this.memberCaseRecordsStartDate = memberCaseRecordsStartDate;
	}

	public String getMembershipRecordsStartDate() {
		return membershipRecordsStartDate;
	}

	public void setMembershipRecordsStartDate(String membershipRecordsStartDate) {
		this.membershipRecordsStartDate = membershipRecordsStartDate;
	}

	public String getMemberNetworkRecordsStartDate() {
		return memberNetworkRecordsStartDate;
	}

	public void setMemberNetworkRecordsStartDate(String memberNetworkRecordsStartDate) {
		this.memberNetworkRecordsStartDate = memberNetworkRecordsStartDate;
	}

	public String getClaimSummaryRecordsStartDate() {
		return claimSummaryRecordsStartDate;
	}

	public void setClaimSummaryRecordsStartDate(String claimSummaryRecordsStartDate) {
		this.claimSummaryRecordsStartDate = claimSummaryRecordsStartDate;
	}

	public String getClaimLineDetailRecordsStartDate() {
		return claimLineDetailRecordsStartDate;
	}

	public void setClaimLineDetailRecordsStartDate(String claimLineDetailRecordsStartDate) {
		this.claimLineDetailRecordsStartDate = claimLineDetailRecordsStartDate;
	}

	public String getClaimLineEOBRecordsStartDate() {
		return claimLineEOBRecordsStartDate;
	}

	public void setClaimLineEOBRecordsStartDate(String claimLineEOBRecordsStartDate) {
		this.claimLineEOBRecordsStartDate = claimLineEOBRecordsStartDate;
	}

	public String getClaimPaymentRecordsStartDate() {
		return claimPaymentRecordsStartDate;
	}

	public void setClaimPaymentRecordsStartDate(String claimPaymentRecordsStartDate) {
		this.claimPaymentRecordsStartDate = claimPaymentRecordsStartDate;
	}

	public String getClaimEOBLookupRecordsStartDate() {
		return claimEOBLookupRecordsStartDate;
	}

	public void setClaimEOBLookupRecordsStartDate(String claimEOBLookupRecordsStartDate) {
		this.claimEOBLookupRecordsStartDate = claimEOBLookupRecordsStartDate;
	}

	public String getClaimInquiryRecordsStartDate() {
		return claimInquiryRecordsStartDate;
	}

	public void setClaimInquiryRecordsStartDate(String claimInquiryRecordsStartDate) {
		this.claimInquiryRecordsStartDate = claimInquiryRecordsStartDate;
	}

}
