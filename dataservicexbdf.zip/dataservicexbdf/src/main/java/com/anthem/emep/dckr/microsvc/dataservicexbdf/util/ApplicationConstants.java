package com.anthem.emep.dckr.microsvc.dataservicexbdf.util;

public class ApplicationConstants {

	public static final String HIVE_PASSWRD = "password";

	public static final String HIVE_USERNAME = "username";

	public static final String HIVE_DRIVER_CLASS_NAME = "driverclassname";

	public static final String HIVE_URL = "url";

	public static final String HIVE_JDBC_DATA_SOURCE = "hiveJdbcDS";

	public static final String MONGO_URI = "mongo.datasource.srvexpdb.uri";

	public static final String KAFKA_TOPIC_NAME = "kafka.servicebdf.topic";

}
