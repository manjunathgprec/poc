package com.anthem.emep.dckr.microsvc.dataservicexbdf.config;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ExecutorServiceConfig {

	@Bean
	public ExecutorService executorService() {
		// Increase the threads based on the no of tables
		return Executors.newFixedThreadPool(2);
	}

}
