package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Class holds the MEMBER_KEY from Person json obj
 * 
 * @author AG59866
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PrsnMemberKeys {

	private String mbr4Pkey;
	private String mbrHcid;
	private String mbrHashkey;
	private String mbrSubscriber;
	private String mbrEhubid;
	private String mbrDgtlEnrlmntRel;

	@JsonProperty("mbr4pkey") // kafka message property
	public String getMbr4Pkey() {
		return mbr4Pkey;
	}

	@JsonProperty("mbr4Pkey")  // DB property
	public void setMbr4Pkey(String mbr4Pkey) {
		this.mbr4Pkey = mbr4Pkey;
	}

	@JsonProperty("mbrhcid")
	public String getMbrHcid() {
		return mbrHcid;
	}

	@JsonProperty("mbrHcid")
	public void setMbrHcid(String mbrHcid) {
		this.mbrHcid = mbrHcid;
	}

	@JsonProperty("mbrhashkey")
	public String getMbrHashkey() {
		return mbrHashkey;
	}

	@JsonProperty("mbrHashkey")
	public void setMbrHashkey(String mbrHashkey) {
		this.mbrHashkey = mbrHashkey;
	}

	@JsonProperty("mbrsubscriber")
	public String getMbrSubscriber() {
		return mbrSubscriber;
	}

	@JsonProperty("mbrSubscriber")
	public void setMbrSubscriber(String mbrSubscriber) {
		this.mbrSubscriber = mbrSubscriber;
	}

	@JsonProperty("mbrehubid")
	public String getMbrEhubid() {
		return mbrEhubid;
	}

	@JsonProperty("mbrEhubid")
	public void setMbrEhubid(String mbrEhubid) {
		this.mbrEhubid = mbrEhubid;
	}

	@JsonProperty("mbrdgtlenrlmntrel")
	public String getMbrDgtlEnrlmntRel() {
		return mbrDgtlEnrlmntRel;
	}

	@JsonProperty("mbrDgtlEnrlmntRel")
	public void setMbrDgtlEnrlmntRel(String mbrDgtlEnrlmntRel) {
		this.mbrDgtlEnrlmntRel = mbrDgtlEnrlmntRel;
	}
}