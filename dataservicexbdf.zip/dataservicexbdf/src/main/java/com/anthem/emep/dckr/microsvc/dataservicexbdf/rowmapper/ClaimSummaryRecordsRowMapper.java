package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimSummaryRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;

public class ClaimSummaryRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(ClaimSummaryRecordsRowMapper.class);

	private String messageType;

	public ClaimSummaryRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public ClaimSummaryRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		ClaimSummaryRecords claimSummaryRecords = new ClaimSummaryRecords();

		// Meta fields mapping
		claimSummaryRecords.setMetaMsgType(messageType);
		claimSummaryRecords.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		claimSummaryRecords.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		claimSummaryRecords.setMetaRecLtstUpdtGuid(rs.getString("guid"));
		
		claimSummaryRecords.setClmMbrSorCd("808");
		claimSummaryRecords.setClmMbrGrpNbr(rs.getString("DDC_CD_CASE_NBR")); 
		claimSummaryRecords.setClmMbrIdnSubId(rs.getString("DDC_CD_ORIG_CERT_NBR")); 
		claimSummaryRecords.setClmMbrSqncNbr(rs.getDouble("DDC_CD_PAT_MBR_SEQ_NBR")); 
		claimSummaryRecords.setClmId(rs.getString("GNCHIIOS_HCLM_DCN_CC" +"-"+ "GNCHIIOS_HCLM_DCN"));		
		claimSummaryRecords.setPkeyClmId(claimSummaryRecords.getClmId());
		claimSummaryRecords.setClmAdjstmntNbr(rs.getDouble("GNCHIIOS_HCLM_SEQ_NBR")); 
		claimSummaryRecords.setClmItemCd(rs.getString("GNCHIIOS_HCLM_ITEM_CDE")); 
		claimSummaryRecords.setClmProvFullNm(rs.getString("DDC_CD_PRVDR_NME"));
		claimSummaryRecords.setClmProvScndryNm(rs.getString("DDC_CD_PRVDR_SEC_NME"));
		claimSummaryRecords.setClmProvIdTypeCd(rs.getString("DDC_CD_PRVDR_TYPE_CDE"));
		claimSummaryRecords.setClmDdctblAmt(rs.getDouble("DDC_CD_DEDUCT_AMT"));
		claimSummaryRecords.setClmTotlDdctblAmt(rs.getDouble("DDC_CD_TOT_DEDUCT_AMT"));
		claimSummaryRecords.setClmTotlDdctblMbrAmt(rs.getDouble("DDC_CD_TOT_DEDUCT_MBR_AMT"));
		claimSummaryRecords.setClmTotlDdctblFmlyAmt(rs.getDouble("DDC_CD_TOT_DEDUCT_FMLY_AMT"));
		// clmMbrSorCd-clmMbrGrpNbr-clmMbrIdnSubId-clmMbrSqncNbr - primary key
		claimSummaryRecords.setSkeyMbr4PartRefNo(claimSummaryRecords.getClmMbrSorCd() +"-"+ claimSummaryRecords.getClmMbrGrpNbr() +"-"+ claimSummaryRecords.getClmMbrIdnSubId() +"-"+ claimSummaryRecords.getClmMbrSqncNbr());
				
		claimSummaryRecords.setClmTotlBilldChrgAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlAlwdAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlPaidAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlCoInsuAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlCoPaymntAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlNonElgAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlMbrLiablAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlPartBAprvdAmt(rs.getDouble(""));
		claimSummaryRecords.setClmTotlPartBPaidAmt(rs.getDouble(""));
		//claimSummaryRecords.setClmLstUpdtDt(rs.getInt("DDC_CD_PROC_DTE")); // field missing
		claimSummaryRecords.setClmStrtDt(rs.getDouble("DDC_CD_SVC_FROM_DTE")); 
		claimSummaryRecords.setClmEndDt(rs.getDouble("DDC_CD_SVC_THRU_DTE")); 
		claimSummaryRecords.setClmSttsCd(rs.getString("DDC_CD_CURR_STS_CDE"));
		claimSummaryRecords.setClmProdGrpId(rs.getString("DDC_CD_GRP_NBR"));	
		claimSummaryRecords.setClmPrimNetCde(rs.getString("DDC_CD_PRIM_NET_CDE")); 
		claimSummaryRecords.setClmTotlProvWoAmt(rs.getDouble(""));
		claimSummaryRecords.setClmSrvcInqCount(rs.getInt(""));
		claimSummaryRecords.setClmDtlCntr(rs.getInt("ddc_cd_cntr_2")); 
		claimSummaryRecords.setClmEobCntr(rs.getInt("ddc_cd_cntr_5")); 
		

		return claimSummaryRecords;
	}

}
