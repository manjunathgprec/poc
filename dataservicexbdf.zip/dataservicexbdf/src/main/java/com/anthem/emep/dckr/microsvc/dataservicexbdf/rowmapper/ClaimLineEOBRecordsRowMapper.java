package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimLineEobRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;

public class ClaimLineEOBRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(ClaimLineEOBRecordsRowMapper.class);

	private String messageType;

	public ClaimLineEOBRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public ClaimLineEobRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		ClaimLineEobRecords claimLineEobRecords = new ClaimLineEobRecords();

		// Meta fields mapping
		claimLineEobRecords.setMetaMsgType(messageType);
		claimLineEobRecords.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		claimLineEobRecords.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		claimLineEobRecords.setMetaRecLtstUpdtGuid(rs.getString("guid"));

		claimLineEobRecords.setClmId(StringUtils.trimWhitespace(rs.getString("GNCHIIOS-HCLM-DCN-CC" +"-"+ "GNCHIIOS_HCLM_DCN")));
		claimLineEobRecords.setClmLineEobLineNbr(StringUtils.trimWhitespace(rs.getString("DDC_EOB_DTL_LNE_NBR")));
		claimLineEobRecords.setClmLineEobSeqNbr(rs.getDouble("GNCHIIOS_HCLM_SEQ_NBR"));
		claimLineEobRecords.setClmLineEobItmCde(StringUtils.trimWhitespace(rs.getString("GNCHIIOS_HCLM_ITM_CDE")));
		claimLineEobRecords.setClmLineEobSrvcExplntnCd(StringUtils.trimWhitespace(rs.getString("DDC_EOB_CDE")));
		claimLineEobRecords.setClmLineEobSrvcExplntnAmt(rs.getDouble("DDC_EOB_AMT"));
		// Primarykey
		claimLineEobRecords.setPkeyClmEobRefNo(claimLineEobRecords.getClmId() +"-"+ claimLineEobRecords.getClmLineEobLineNbr() +"-"+ claimLineEobRecords.getClmLineEobSrvcExplntnCd());

		return claimLineEobRecords;
	}

}
