package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * POJO class to represent the state of soa-bdf-mbr-ntwk-seg-v01
 * 
 * @author ag59866
 *
 */
@JsonPropertyOrder({ "pkeyMbrNtkRefNo", "mbrSorCd", "mbrGrpId", "mbrIdnSubId", "mbrSqncNbr", "mbrPcpId",
		"mbrPcpEfctvDt", "mbrPcpTrmntnDt", "mbrPcpLstProcDt", "mbrPcpPicSw", "mbrInsurType" })

@Document(collection = EventsModelConstants.MEMBERNETWORK_COLLECION)
public class MemberNetworkRecords extends BaseEntity {

	private String pkeyMbrNtkRefNo;
	private String mbrSorCd;
	private String mbrGrpId;
	private String mbrIdnSubId;
	private Integer mbrSqncNbr;
	private String mbrPcpId;
	private Integer mbrPcpEfctvDt;
	private Integer mbrPcpTrmntnDt;
	private Integer mbrPcpLstProcDt;
	private String mbrPcpPicSw;
	private String mbrInsurType;

	public String getPkeyMbrNtkRefNo() {
		return pkeyMbrNtkRefNo;
	}

	public void setPkeyMbrNtkRefNo(String pkeyMbrNtkRefNo) {
		this.pkeyMbrNtkRefNo = pkeyMbrNtkRefNo;
	}

	public String getMbrSorCd() {
		return mbrSorCd;
	}

	public void setMbrSorCd(String mbrSorCd) {
		this.mbrSorCd = mbrSorCd;
	}

	public String getMbrGrpId() {
		return mbrGrpId;
	}

	public void setMbrGrpId(String mbrGrpId) {
		this.mbrGrpId = mbrGrpId;
	}

	public String getMbrIdnSubId() {
		return mbrIdnSubId;
	}

	public void setMbrIdnSubId(String mbrIdnSubId) {
		this.mbrIdnSubId = mbrIdnSubId;
	}

	public Integer getMbrSqncNbr() {
		return mbrSqncNbr;
	}

	public void setMbrSqncNbr(Integer mbrSqncNbr) {
		this.mbrSqncNbr = mbrSqncNbr;
	}

	public String getMbrPcpId() {
		return mbrPcpId;
	}

	public void setMbrPcpId(String mbrPcpId) {
		this.mbrPcpId = mbrPcpId;
	}

	public Integer getMbrPcpEfctvDt() {
		return mbrPcpEfctvDt;
	}

	public void setMbrPcpEfctvDt(Integer mbrPcpEfctvDt) {
		this.mbrPcpEfctvDt = mbrPcpEfctvDt;
	}

	public Integer getMbrPcpTrmntnDt() {
		return mbrPcpTrmntnDt;
	}

	public void setMbrPcpTrmntnDt(Integer mbrPcpTrmntnDt) {
		this.mbrPcpTrmntnDt = mbrPcpTrmntnDt;
	}

	public Integer getMbrPcpLstProcDt() {
		return mbrPcpLstProcDt;
	}

	public void setMbrPcpLstProcDt(Integer mbrPcpLstProcDt) {
		this.mbrPcpLstProcDt = mbrPcpLstProcDt;
	}

	public String getMbrPcpPicSw() {
		return mbrPcpPicSw;
	}

	public void setMbrPcpPicSw(String mbrPcpPicSw) {
		this.mbrPcpPicSw = mbrPcpPicSw;
	}

	public String getMbrInsurType() {
		return mbrInsurType;
	}

	public void setMbrInsurType(String mbrInsurType) {
		this.mbrInsurType = mbrInsurType;
	};

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static MemberNetworkRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		MemberNetworkRecords mbrNtwk = null;
		mbrNtwk = mapper.readValue(jsonString, MemberNetworkRecords.class);
		return mbrNtwk;
	}

}
