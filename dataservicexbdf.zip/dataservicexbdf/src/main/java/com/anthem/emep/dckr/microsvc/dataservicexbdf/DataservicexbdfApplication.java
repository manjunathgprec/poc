package com.anthem.emep.dckr.microsvc.dataservicexbdf;

import org.springframework.web.bind.annotation.RestController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.service.impl.EhubDataStoreSchedulerService;

@RestController
@SpringBootApplication
public class DataservicexbdfApplication implements CommandLineRunner {

	private Logger logger = LoggerFactory.getLogger(DataservicexbdfApplication.class);

	@Autowired
	private EhubDataStoreSchedulerService ehubDataStoreSchedulerService;

	public static void main(String[] args) {
		SpringApplication.run(DataservicexbdfApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		logger.info("JOB has started to process the data from hive data store");

		ehubDataStoreSchedulerService.call();

		logger.info("JOB has ended to process the data from hive data store");
	}

}
