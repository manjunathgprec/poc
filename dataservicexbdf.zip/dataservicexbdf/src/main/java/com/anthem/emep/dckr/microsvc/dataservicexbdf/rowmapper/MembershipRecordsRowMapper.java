package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MembershipRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;

public class MembershipRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(MembershipRecordsRowMapper.class);

	private String messageType;

	public MembershipRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public MembershipRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		MembershipRecords membershipRecords = new MembershipRecords();

		// Meta fields mapping
		membershipRecords.setMetaMsgType(messageType);
		membershipRecords.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		membershipRecords.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		membershipRecords.setMetaRecLtstUpdtGuid(rs.getString("guid"));
		
		membershipRecords.setMbrSorCd("808");
		membershipRecords.setMbrGrpNbr(StringUtils.trimWhitespace(rs.getString("NM_MEMB_CASE_NBR")));
		membershipRecords.setMbrGrpId(StringUtils.trimWhitespace(rs.getString("nm_cont_grp_sufx_cb"))); 
		membershipRecords.setMbrIdnSubId(rs.getString("NM_CERT_NO")); //cert no?
		membershipRecords.setMbrSqncNbr(rs.getInt("NM_MEMB_MBR_SEQ_NBR"));
		membershipRecords.setMbrLstUpdDt(rs.getInt("NM_MEMB_LST_UPDT_DTE")); 
		membershipRecords.setMbrCurrBegDt(rs.getInt("NM_MEMB_CURR_BEG_DTE")); 
		membershipRecords.setMbrCanEffDt(rs.getInt("NM_MEMB_CAN_EFF_DTE"));
		membershipRecords.setMbrGracAdjstdTrmntnDt(rs.getInt("NM_MEMB_END_DTE"));
		membershipRecords.setMbrCd(rs.getInt("NM_MEMB_MBR_CD"));
		membershipRecords.setMbrStatusCd(rs.getString("nm_memb_stat_cd"));
		membershipRecords.setMbrGrpStCd("");
		membershipRecords.setMbrNatlAcctCd("");
		//mbrSorCd-mbrGrpNbr-mbrIdnSubId-mbrSqncNbr - primary key
		membershipRecords.setPkeyMbr4PartRefNo(membershipRecords.getMbrSorCd() +"-"+ membershipRecords.getMbrGrpNbr() +"-"+ membershipRecords.getMbrIdnSubId() +"-"+ membershipRecords.getMbrSqncNbr()); 
		//mbrGrpId-mbrIdnSubId-mbrSqncNbr
		membershipRecords.setSkeyMbrNtkRefNo(membershipRecords.getMbrGrpNbr() +"-"+ membershipRecords.getMbrIdnSubId() +"-"+ membershipRecords.getMbrSqncNbr()); 
				
		return membershipRecords;
	}

}
