package com.anthem.emep.dckr.microsvc.dataservicexbdf.config;

public class EventsModelConstants {

	EventsModelConstants() {
	}

	public static final String EVENT_COLLECION = "sxBTMessageEvents";
	public static final String AGGREGATE_COLLECION = "sxBTAggregatedEvents";
	public static final String EOBLOOKUP_COLLECION = "sxClaimEOBLookupRecords";
	public static final String PSEUDOOBJECT_COLLECION = "sxPseudoObjects";
	public static final String PERSONPROXY_COLLECION = "sxPersonProxyRecords";
	public static final String MEMBERSHIP_COLLECION = "sxMembershipRecords";
	public static final String MEMBERNETWORK_COLLECION = "sxMemberNetworkRecords";
	public static final String CLAIMSUMMARY_COLLECION = "sxClaimSummaryRecords";
	public static final String CLAIMLINEEOB_COLLECION = "sxClaimLineEobRecords";
	public static final String CLAIMLINEDETAIL_COLLECION = "sxClaimLineDetailRecords";
	public static final String CLAIMINQUIRY_COLLECION = "sxClaimInquiryRecords";
	public static final String PAYMENT_COLLECION = "sxClaimPaymentRecords";
	public static final String MEMBERCASE_COLLECION = "sxMemberCaseRecords";

}
