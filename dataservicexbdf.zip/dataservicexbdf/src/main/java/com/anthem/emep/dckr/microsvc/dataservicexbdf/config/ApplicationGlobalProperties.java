package com.anthem.emep.dckr.microsvc.dataservicexbdf.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties // no prefix, root level.
public class ApplicationGlobalProperties {

	@Value("${JOB_START_DATE:#{null}}")
	private String jobStartDate;

	@Value("${JOB_END_DATE:#{null}}")
	private String jobEndDate;

	// Msg types from configuration file
	@Value("${personProxyRecordsMsgType}")
	private String personProxyRecordsMsgType;
	@Value("${memberCaseRecordsMsgType}")
	private String memberCaseRecordsMsgType;
	@Value("${membershipRecordsMsgType}")
	private String membershipRecordsMsgType;
	@Value("${memberNetworkRecordsMsgType}")
	private String memberNetworkRecordsMsgType;
	@Value("${claimSummaryRecordsMsgType}")
	private String claimSummaryRecordsMsgType;
	@Value("${claimLineDetailRecordsMsgType}")
	private String claimLineDetailRecordsMsgType;
	@Value("${claimLineEOBRecordsMsgType}")
	private String claimLineEOBRecordsMsgType;
	@Value("${claimPaymentRecordsMsgType}")
	private String claimPaymentRecordsMsgType;
	@Value("${claimEOBLookupRecordsMsgType}")
	private String claimEOBLookupRecordsMsgType;
	@Value("${claimInquiryRecordsMsgType}")
	private String claimInquiryRecordsMsgType;

	// Table names from configuration file
	@Value("${personProxyRecordsTblName}")
	private String personProxyRecordsTblName;
	@Value("${memberCaseRecordsTblName}")
	private String memberCaseRecordsTblName;
	@Value("${membershipRecordsTblName}")
	private String membershipRecordsTblName;
	@Value("${memberNetworkRecordsTblName}")
	private String memberNetworkRecordsTblName;
	@Value("${claimSummaryRecordsTblName}")
	private String claimSummaryRecordsTblName;
	@Value("${claimLineDetailRecordsTblName}")
	private String claimLineDetailRecordsTblName;
	@Value("${claimLineEOBRecordsTblName}")
	private String claimLineEOBRecordsTblName;
	@Value("${claimPaymentRecordsTblName}")
	private String claimPaymentRecordsTblName;
	@Value("${claimEOBLookupRecordsTblName}")
	private String claimEOBLookupRecordsTblName;
	@Value("${claimInquiryRecordsTblName}")
	private String claimInquiryRecordsTblName;

	@Value("${page_size}")
	int pageSize;

	@Value("${personProxyRecordsCountQuery}")
	private String personProxyRecordsCountQuery;
	@Value("${personProxyRecordsDataQuery}")
	private String personProxyRecordsDataQuery;

	@Value("${memberCaseRecordsCountQuery}")
	private String memberCaseRecordsCountQuery;
	@Value("${memberCaseRecordsDataQuery}")
	private String memberCaseRecordsDataQuery;

	@Value("${membershipRecordsCountQuery}")
	private String membershipRecordsCountQuery;
	@Value("${membershipRecordsDataQuery}")
	private String membershipRecordsDataQuery;

	@Value("${memberNetworkRecordsCountQuery}")
	private String memberNetworkRecordsCountQuery;
	@Value("${memberNetworkRecordsDataQuery}")
	private String memberNetworkRecordsDataQuery;

	@Value("${claimSummaryRecordsCountQuery}")
	private String claimSummaryRecordsCountQuery;
	@Value("${claimSummaryRecordsDataQuery}")
	private String claimSummaryRecordsDataQuery;

	@Value("${claimLineDetailRecordsCountQuery}")
	private String claimLineDetailRecordsCountQuery;
	@Value("${claimLineDetailRecordsDataQuery}")
	private String claimLineDetailRecordsDataQuery;

	@Value("${claimLineEOBRecordsCountQuery}")
	private String claimLineEOBRecordsCountQuery;
	@Value("${claimLineEOBRecordsDataQuery}")
	private String claimLineEOBRecordsDataQuery;

	@Value("${claimPaymentRecordsCountQuery}")
	private String claimPaymentRecordsCountQuery;
	@Value("${claimPaymentRecordsDataQuery}")
	private String claimPaymentRecordsDataQuery;

	@Value("${claimEOBLookupRecordsCountQuery}")
	private String claimEOBLookupRecordsCountQuery;
	@Value("${claimEOBLookupRecordsDataQuery}")
	private String claimEOBLookupRecordsDataQuery;

	@Value("${claimInquiryRecordsCountQuery}")
	private String claimInquiryRecordsCountQuery;
	@Value("${claimInquiryRecordsDataQuery}")
	private String claimInquiryRecordsDataQuery;

	public String getJobStartDate() {
		return jobStartDate;
	}

	public void setJobStartDate(String jobStartDate) {
		this.jobStartDate = jobStartDate;
	}

	public String getJobEndDate() {
		return jobEndDate;
	}

	public void setJobEndDate(String jobEndDate) {
		this.jobEndDate = jobEndDate;
	}

	public String getPersonProxyRecordsMsgType() {
		return personProxyRecordsMsgType;
	}

	public void setPersonProxyRecordsMsgType(String personProxyRecordsMsgType) {
		this.personProxyRecordsMsgType = personProxyRecordsMsgType;
	}

	public String getMemberCaseRecordsMsgType() {
		return memberCaseRecordsMsgType;
	}

	public void setMemberCaseRecordsMsgType(String memberCaseRecordsMsgType) {
		this.memberCaseRecordsMsgType = memberCaseRecordsMsgType;
	}

	public String getMembershipRecordsMsgType() {
		return membershipRecordsMsgType;
	}

	public void setMembershipRecordsMsgType(String membershipRecordsMsgType) {
		this.membershipRecordsMsgType = membershipRecordsMsgType;
	}

	public String getMemberNetworkRecordsMsgType() {
		return memberNetworkRecordsMsgType;
	}

	public void setMemberNetworkRecordsMsgType(String memberNetworkRecordsMsgType) {
		this.memberNetworkRecordsMsgType = memberNetworkRecordsMsgType;
	}

	public String getClaimSummaryRecordsMsgType() {
		return claimSummaryRecordsMsgType;
	}

	public void setClaimSummaryRecordsMsgType(String claimSummaryRecordsMsgType) {
		this.claimSummaryRecordsMsgType = claimSummaryRecordsMsgType;
	}

	public String getClaimLineDetailRecordsMsgType() {
		return claimLineDetailRecordsMsgType;
	}

	public void setClaimLineDetailRecordsMsgType(String claimLineDetailRecordsMsgType) {
		this.claimLineDetailRecordsMsgType = claimLineDetailRecordsMsgType;
	}

	public String getClaimLineEOBRecordsMsgType() {
		return claimLineEOBRecordsMsgType;
	}

	public void setClaimLineEOBRecordsMsgType(String claimLineEOBRecordsMsgType) {
		this.claimLineEOBRecordsMsgType = claimLineEOBRecordsMsgType;
	}

	public String getClaimPaymentRecordsMsgType() {
		return claimPaymentRecordsMsgType;
	}

	public void setClaimPaymentRecordsMsgType(String claimPaymentRecordsMsgType) {
		this.claimPaymentRecordsMsgType = claimPaymentRecordsMsgType;
	}

	public String getClaimEOBLookupRecordsMsgType() {
		return claimEOBLookupRecordsMsgType;
	}

	public void setClaimEOBLookupRecordsMsgType(String claimEOBLookupRecordsMsgType) {
		this.claimEOBLookupRecordsMsgType = claimEOBLookupRecordsMsgType;
	}

	public String getClaimInquiryRecordsMsgType() {
		return claimInquiryRecordsMsgType;
	}

	public void setClaimInquiryRecordsMsgType(String claimInquiryRecordsMsgType) {
		this.claimInquiryRecordsMsgType = claimInquiryRecordsMsgType;
	}

	public String getPersonProxyRecordsTblName() {
		return personProxyRecordsTblName;
	}

	public void setPersonProxyRecordsTblName(String personProxyRecordsTblName) {
		this.personProxyRecordsTblName = personProxyRecordsTblName;
	}

	public String getMemberCaseRecordsTblName() {
		return memberCaseRecordsTblName;
	}

	public void setMemberCaseRecordsTblName(String memberCaseRecordsTblName) {
		this.memberCaseRecordsTblName = memberCaseRecordsTblName;
	}

	public String getMembershipRecordsTblName() {
		return membershipRecordsTblName;
	}

	public void setMembershipRecordsTblName(String membershipRecordsTblName) {
		this.membershipRecordsTblName = membershipRecordsTblName;
	}

	public String getMemberNetworkRecordsTblName() {
		return memberNetworkRecordsTblName;
	}

	public void setMemberNetworkRecordsTblName(String memberNetworkRecordsTblName) {
		this.memberNetworkRecordsTblName = memberNetworkRecordsTblName;
	}

	public String getClaimSummaryRecordsTblName() {
		return claimSummaryRecordsTblName;
	}

	public void setClaimSummaryRecordsTblName(String claimSummaryRecordsTblName) {
		this.claimSummaryRecordsTblName = claimSummaryRecordsTblName;
	}

	public String getClaimLineDetailRecordsTblName() {
		return claimLineDetailRecordsTblName;
	}

	public void setClaimLineDetailRecordsTblName(String claimLineDetailRecordsTblName) {
		this.claimLineDetailRecordsTblName = claimLineDetailRecordsTblName;
	}

	public String getClaimLineEOBRecordsTblName() {
		return claimLineEOBRecordsTblName;
	}

	public void setClaimLineEOBRecordsTblName(String claimLineEOBRecordsTblName) {
		this.claimLineEOBRecordsTblName = claimLineEOBRecordsTblName;
	}

	public String getClaimPaymentRecordsTblName() {
		return claimPaymentRecordsTblName;
	}

	public void setClaimPaymentRecordsTblName(String claimPaymentRecordsTblName) {
		this.claimPaymentRecordsTblName = claimPaymentRecordsTblName;
	}

	public String getClaimEOBLookupRecordsTblName() {
		return claimEOBLookupRecordsTblName;
	}

	public void setClaimEOBLookupRecordsTblName(String claimEOBLookupRecordsTblName) {
		this.claimEOBLookupRecordsTblName = claimEOBLookupRecordsTblName;
	}

	public String getClaimInquiryRecordsTblName() {
		return claimInquiryRecordsTblName;
	}

	public void setClaimInquiryRecordsTblName(String claimInquiryRecordsTblName) {
		this.claimInquiryRecordsTblName = claimInquiryRecordsTblName;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public String getPersonProxyRecordsCountQuery() {
		return personProxyRecordsCountQuery;
	}

	public void setPersonProxyRecordsCountQuery(String personProxyRecordsCountQuery) {
		this.personProxyRecordsCountQuery = personProxyRecordsCountQuery;
	}

	public String getPersonProxyRecordsDataQuery() {
		return personProxyRecordsDataQuery;
	}

	public void setPersonProxyRecordsDataQuery(String personProxyRecordsDataQuery) {
		this.personProxyRecordsDataQuery = personProxyRecordsDataQuery;
	}

	public String getMemberCaseRecordsCountQuery() {
		return memberCaseRecordsCountQuery;
	}

	public void setMemberCaseRecordsCountQuery(String memberCaseRecordsCountQuery) {
		this.memberCaseRecordsCountQuery = memberCaseRecordsCountQuery;
	}

	public String getMemberCaseRecordsDataQuery() {
		return memberCaseRecordsDataQuery;
	}

	public void setMemberCaseRecordsDataQuery(String memberCaseRecordsDataQuery) {
		this.memberCaseRecordsDataQuery = memberCaseRecordsDataQuery;
	}

	public String getMembershipRecordsCountQuery() {
		return membershipRecordsCountQuery;
	}

	public void setMembershipRecordsCountQuery(String membershipRecordsCountQuery) {
		this.membershipRecordsCountQuery = membershipRecordsCountQuery;
	}

	public String getMembershipRecordsDataQuery() {
		return membershipRecordsDataQuery;
	}

	public void setMembershipRecordsDataQuery(String membershipRecordsDataQuery) {
		this.membershipRecordsDataQuery = membershipRecordsDataQuery;
	}

	public String getMemberNetworkRecordsCountQuery() {
		return memberNetworkRecordsCountQuery;
	}

	public void setMemberNetworkRecordsCountQuery(String memberNetworkRecordsCountQuery) {
		this.memberNetworkRecordsCountQuery = memberNetworkRecordsCountQuery;
	}

	public String getMemberNetworkRecordsDataQuery() {
		return memberNetworkRecordsDataQuery;
	}

	public void setMemberNetworkRecordsDataQuery(String memberNetworkRecordsDataQuery) {
		this.memberNetworkRecordsDataQuery = memberNetworkRecordsDataQuery;
	}

	public String getClaimSummaryRecordsCountQuery() {
		return claimSummaryRecordsCountQuery;
	}

	public void setClaimSummaryRecordsCountQuery(String claimSummaryRecordsCountQuery) {
		this.claimSummaryRecordsCountQuery = claimSummaryRecordsCountQuery;
	}

	public String getClaimSummaryRecordsDataQuery() {
		return claimSummaryRecordsDataQuery;
	}

	public void setClaimSummaryRecordsDataQuery(String claimSummaryRecordsDataQuery) {
		this.claimSummaryRecordsDataQuery = claimSummaryRecordsDataQuery;
	}

	public String getClaimLineDetailRecordsCountQuery() {
		return claimLineDetailRecordsCountQuery;
	}

	public void setClaimLineDetailRecordsCountQuery(String claimLineDetailRecordsCountQuery) {
		this.claimLineDetailRecordsCountQuery = claimLineDetailRecordsCountQuery;
	}

	public String getClaimLineDetailRecordsDataQuery() {
		return claimLineDetailRecordsDataQuery;
	}

	public void setClaimLineDetailRecordsDataQuery(String claimLineDetailRecordsDataQuery) {
		this.claimLineDetailRecordsDataQuery = claimLineDetailRecordsDataQuery;
	}

	public String getClaimLineEOBRecordsCountQuery() {
		return claimLineEOBRecordsCountQuery;
	}

	public void setClaimLineEOBRecordsCountQuery(String claimLineEOBRecordsCountQuery) {
		this.claimLineEOBRecordsCountQuery = claimLineEOBRecordsCountQuery;
	}

	public String getClaimLineEOBRecordsDataQuery() {
		return claimLineEOBRecordsDataQuery;
	}

	public void setClaimLineEOBRecordsDataQuery(String claimLineEOBRecordsDataQuery) {
		this.claimLineEOBRecordsDataQuery = claimLineEOBRecordsDataQuery;
	}

	public String getClaimPaymentRecordsCountQuery() {
		return claimPaymentRecordsCountQuery;
	}

	public void setClaimPaymentRecordsCountQuery(String claimPaymentRecordsCountQuery) {
		this.claimPaymentRecordsCountQuery = claimPaymentRecordsCountQuery;
	}

	public String getClaimPaymentRecordsDataQuery() {
		return claimPaymentRecordsDataQuery;
	}

	public void setClaimPaymentRecordsDataQuery(String claimPaymentRecordsDataQuery) {
		this.claimPaymentRecordsDataQuery = claimPaymentRecordsDataQuery;
	}

	public String getClaimEOBLookupRecordsCountQuery() {
		return claimEOBLookupRecordsCountQuery;
	}

	public void setClaimEOBLookupRecordsCountQuery(String claimEOBLookupRecordsCountQuery) {
		this.claimEOBLookupRecordsCountQuery = claimEOBLookupRecordsCountQuery;
	}

	public String getClaimEOBLookupRecordsDataQuery() {
		return claimEOBLookupRecordsDataQuery;
	}

	public void setClaimEOBLookupRecordsDataQuery(String claimEOBLookupRecordsDataQuery) {
		this.claimEOBLookupRecordsDataQuery = claimEOBLookupRecordsDataQuery;
	}

	public String getClaimInquiryRecordsCountQuery() {
		return claimInquiryRecordsCountQuery;
	}

	public void setClaimInquiryRecordsCountQuery(String claimInquiryRecordsCountQuery) {
		this.claimInquiryRecordsCountQuery = claimInquiryRecordsCountQuery;
	}

	public String getClaimInquiryRecordsDataQuery() {
		return claimInquiryRecordsDataQuery;
	}

	public void setClaimInquiryRecordsDataQuery(String claimInquiryRecordsDataQuery) {
		this.claimInquiryRecordsDataQuery = claimInquiryRecordsDataQuery;
	}

}
