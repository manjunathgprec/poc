package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * POJO class to represent the state of soa-bdf-mbr-seg-v01
 * 
 * @author ag59866
 *
 */
@Document(collection = EventsModelConstants.MEMBERSHIP_COLLECION)
public class MembershipRecords extends BaseEntity {

	private String pkeyMbr4PartRefNo;
	private String skeyMbrNtkRefNo;
	private String mbrSorCd;
	private String mbrGrpNbr;
	private String mbrGrpId;
	private String mbrIdnSubId;
	private Integer mbrSqncNbr;
	private Integer mbrLstUpdDt;
	private Integer mbrCurrBegDt;
	private Integer mbrCanEffDt;
	private Integer mbrGracAdjstdTrmntnDt;
	private Integer mbrCd;
	private String mbrStatusCd;
	private String mbrGrpStCd;
	private String mbrNatlAcctCd;

	public String getPkeyMbr4PartRefNo() {
		return pkeyMbr4PartRefNo;
	}

	public void setPkeyMbr4PartRefNo(String pkeyMbr4PartRefNo) {
		this.pkeyMbr4PartRefNo = pkeyMbr4PartRefNo;
	}

	public String getSkeyMbrNtkRefNo() {
		return skeyMbrNtkRefNo;
	}

	public void setSkeyMbrNtkRefNo(String skeyMbrNtkRefNo) {
		this.skeyMbrNtkRefNo = skeyMbrNtkRefNo;
	}

	public String getMbrSorCd() {
		return mbrSorCd;
	}

	public void setMbrSorCd(String mbrSorCd) {
		this.mbrSorCd = mbrSorCd;
	}

	public String getMbrGrpNbr() {
		return mbrGrpNbr;
	}

	public void setMbrGrpNbr(String mbrGrpNbr) {
		this.mbrGrpNbr = mbrGrpNbr;
	}

	public String getMbrGrpId() {
		return mbrGrpId;
	}

	public void setMbrGrpId(String mbrGrpId) {
		this.mbrGrpId = mbrGrpId;
	}

	public String getMbrIdnSubId() {
		return mbrIdnSubId;
	}

	public void setMbrIdnSubId(String mbrIdnSubId) {
		this.mbrIdnSubId = mbrIdnSubId;
	}

	public Integer getMbrSqncNbr() {
		return mbrSqncNbr;
	}

	public void setMbrSqncNbr(Integer mbrSqncNbr) {
		this.mbrSqncNbr = mbrSqncNbr;
	}

	public Integer getMbrLstUpdDt() {
		return mbrLstUpdDt;
	}

	public void setMbrLstUpdDt(Integer mbrLstUpdDt) {
		this.mbrLstUpdDt = mbrLstUpdDt;
	}

	public Integer getMbrCurrBegDt() {
		return mbrCurrBegDt;
	}

	public void setMbrCurrBegDt(Integer mbrCurrBegDt) {
		this.mbrCurrBegDt = mbrCurrBegDt;
	}

	public Integer getMbrCanEffDt() {
		return mbrCanEffDt;
	}

	public void setMbrCanEffDt(Integer mbrCanEffDt) {
		this.mbrCanEffDt = mbrCanEffDt;
	}

	public Integer getMbrGracAdjstdTrmntnDt() {
		return mbrGracAdjstdTrmntnDt;
	}

	public void setMbrGracAdjstdTrmntnDt(Integer mbrGracAdjstdTrmntnDt) {
		this.mbrGracAdjstdTrmntnDt = mbrGracAdjstdTrmntnDt;
	}

	public Integer getMbrCd() {
		return mbrCd;
	}

	public void setMbrCd(Integer mbrCd) {
		this.mbrCd = mbrCd;
	}

	public String getMbrStatusCd() {
		return mbrStatusCd;
	}

	public void setMbrStatusCd(String mbrStatusCd) {
		this.mbrStatusCd = mbrStatusCd;
	}

	public String getMbrGrpStCd() {
		return mbrGrpStCd;
	}

	public void setMbrGrpStCd(String mbrGrpStCd) {
		this.mbrGrpStCd = mbrGrpStCd;
	}

	public String getMbrNatlAcctCd() {
		return mbrNatlAcctCd;
	}

	public void setMbrNatlAcctCd(String mbrNatlAcctCd) {
		this.mbrNatlAcctCd = mbrNatlAcctCd;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static MembershipRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		MembershipRecords mbrShp = null;
		mbrShp = mapper.readValue(jsonString, MembershipRecords.class);
		return mbrShp;
	}

}
