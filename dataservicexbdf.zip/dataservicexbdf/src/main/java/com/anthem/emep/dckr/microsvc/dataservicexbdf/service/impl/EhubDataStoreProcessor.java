package com.anthem.emep.dckr.microsvc.dataservicexbdf.service.impl;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.Page;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.SearchCriteria;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.service.IProcessor;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.service.kafka.KafkaPublishService;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.PaginationHelper;

/**
 * This class provides the processor implementation for
 * EhubPersonProxyRelationship
 * 
 * @author AG59866
 *
 */
@Service
public class EhubDataStoreProcessor implements IProcessor {

	private Logger logger = LoggerFactory.getLogger(EhubDataStoreProcessor.class);

	@Autowired
	private PaginationHelper<BaseEntity> paginationHelper;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private KafkaPublishService kafkaPublishService;

	@Override
	public void process(SearchCriteria searchCriteria) {

		Object[] args = { searchCriteria.getStartDate(), StringUtils.isEmpty(searchCriteria.getEndDate()) ? null : searchCriteria.getEndDate() };

		long totalRowsCount = paginationHelper.fetchTotalRowsCount(jdbcTemplate, searchCriteria.getSqlCountRows(), args);
		logger.error("############### Total Count ###############" + totalRowsCount);
		if (totalRowsCount >= 0) {
			int pageCount = Math.round(totalRowsCount / searchCriteria.getPageSize());

			if (totalRowsCount > pageCount * searchCriteria.getPageSize()) {
				pageCount++;
			}

			Page<BaseEntity> currentPage = null;
			for (int pageNo = 1; pageNo <= pageCount; pageNo++) {
				currentPage = paginationHelper.fetchPage(jdbcTemplate, searchCriteria.getSqlFetchRows(), args, pageNo, searchCriteria.getPageSize(), searchCriteria.getMapper());
				kafkaPublishService.sendMessage(currentPage, searchCriteria.getTableName());
			}
		} else {
			logger.error("There are no records available for processing ehub_prsnproxy_rltnshp_bt with matching search criteria startDate "
							+ searchCriteria.getStartDate() + " and EndDate is " + searchCriteria.getEndDate());
		}
	}

}
