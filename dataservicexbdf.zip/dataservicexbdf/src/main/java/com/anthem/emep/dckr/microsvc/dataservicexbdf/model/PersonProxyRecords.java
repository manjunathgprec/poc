package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;

@Document(collection = "sxPersonProxyRecords")
public class PersonProxyRecords extends BaseEntity {

	private String pkeyCsPersonId;
	private String csPersonId;
	private Integer prsnEhubPrsnId;
	private String prsnMcid;
	private Date prsnRecLstUpdtDtm;
	private List<PrsnMemberKeys> prsnMemberKeys = new ArrayList<>();

	public String getPkeyCsPersonId() {
		return pkeyCsPersonId;
	}

	public void setPkeyCsPersonId(String pkeyCsPersonId) {
		this.pkeyCsPersonId = pkeyCsPersonId;
	}

	public String getCsPersonId() {
		return csPersonId;
	}

	public void setCsPersonId(String csPersonId) {
		this.csPersonId = csPersonId;
	}

	public Integer getPrsnEhubPrsnId() {
		return prsnEhubPrsnId;
	}

	public void setPrsnEhubPrsnId(Integer prsnEhubPrsnId) {
		this.prsnEhubPrsnId = prsnEhubPrsnId;
	}

	public String getPrsnMcid() {
		return prsnMcid;
	}

	public void setPrsnMcid(String prsnMcid) {
		this.prsnMcid = prsnMcid;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getPrsnRecLstUpdtDtm() {
		return prsnRecLstUpdtDtm;
	}

	public void setPrsnRecLstUpdtDtm(Date prsnRecLstUpdtDtm) {
		this.prsnRecLstUpdtDtm = prsnRecLstUpdtDtm;
	}

	public List<PrsnMemberKeys> getPrsnMemberKeys() {
		return prsnMemberKeys;
	}

	public void setPrsnMemberKeys(List<PrsnMemberKeys> prsnMemberKeys) {
		this.prsnMemberKeys = prsnMemberKeys;
	}

	@Override
	public String toString() {
		return "EhubPrsnProxyRltnshp [pkeyCsPersonId=" + pkeyCsPersonId + ", csPersonId=" + csPersonId
				+ ", prsnEhubPrsnId=" + prsnEhubPrsnId + ", prsnMcid=" + prsnMcid + ", prsnRecLstUpdtDtm="
				+ prsnRecLstUpdtDtm + ", prsnMemberKeys=" + prsnMemberKeys + ", getMetaMsgType()=" + getMetaMsgType()
				+ ", getMetaMsgCreateDtm()=" + getMetaMsgCreateDtm() + ", getMetaRecLtstUpdtDtm()="
				+ getMetaRecLtstUpdtDtm() + ", getMetaRecLtstUpdtGuid()=" + getMetaRecLtstUpdtGuid() + "]";
	}

}
