package com.anthem.emep.dckr.microsvc.dataservicexbdf.config;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.ApplicationConstants;

@Configuration
public class HiveConfig {

	@Autowired
	private ApplicationPropertyConfig config;

	@Bean(name = ApplicationConstants.HIVE_JDBC_DATA_SOURCE)
	@Qualifier(ApplicationConstants.HIVE_JDBC_DATA_SOURCE)
	public DataSource dataSource() {
		DataSource dataSource = new DataSource();
		// dataSource.setUrl(config.getHive().get(ApplicationConstants.HIVE_URL));
		dataSource.setUrl("jdbc:hive2://bddvts2hs2lb.wellpoint.com:10000/Hive;ssl=true");
		dataSource.setDriverClassName(config.getHive().get(ApplicationConstants.HIVE_DRIVER_CLASS_NAME));
		// dataSource.setUsername(config.getHive().get(ApplicationConstants.HIVE_USERNAME));
		dataSource.setUsername("srcOptBDFConn");
		// dataSource.setPassword(config.getHive().get(ApplicationConstants.HIVE_PASSWRD));
		dataSource.setPassword("OptimNew1");
		return dataSource;
	}

	@Bean
	public JdbcTemplate jdbcTemplate(@Qualifier(ApplicationConstants.HIVE_JDBC_DATA_SOURCE) DataSource dataSource) {
		return new JdbcTemplate(dataSource);
	}

}
