package com.anthem.emep.dckr.microsvc.dataservicexbdf.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MemberNetworkRecords;

@Repository
public class MemberNetworkRecordsRepository {

	private static final Logger logger = LoggerFactory.getLogger(MemberNetworkRecordsRepository.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	public MemberNetworkRecords fetchLatestMemberNetworkRecords() {
		logger.info("Inside fetchLatestMemberNetworkRecords");
		Query query = new Query();
		query.limit(1);
		query.with(new Sort(Sort.Direction.DESC, "metaRecLtstUpdtDtm"));
		MemberNetworkRecords data = mongoTemplate.findOne(query, MemberNetworkRecords.class);
		return data;
	}

}
