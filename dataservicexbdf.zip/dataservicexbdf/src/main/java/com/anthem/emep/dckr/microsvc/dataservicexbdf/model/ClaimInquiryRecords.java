package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * POJO class to represent the state of solrctrl-clm-intaction-seg-v01
 * 
 * @author ag59866
 *
 */
@Document(collection = EventsModelConstants.CLAIMINQUIRY_COLLECION)
public class ClaimInquiryRecords extends BaseEntity {

	private String pkeySysClmRefNo;
	private String mbrClmSorCd;
	private String lnkdClmid;
	private Integer lnkdClmsRecvDt;
	private String interaction;
	private String inqTrackingId;
	private String clmSrvcInqCount;

	public String getPkeySysClmRefNo() {
		return pkeySysClmRefNo;
	}

	public void setPkeySysClmRefNo(String pkeySysClmRefNo) {
		this.pkeySysClmRefNo = pkeySysClmRefNo;
	}

	public String getMbrClmSorCd() {
		return mbrClmSorCd;
	}

	public void setMbrClmSorCd(String mbrClmSorCd) {
		this.mbrClmSorCd = mbrClmSorCd;
	}

	public String getLnkdClmid() {
		return lnkdClmid;
	}

	public void setLnkdClmid(String lnkdClmid) {
		this.lnkdClmid = lnkdClmid;
	}

	public Integer getLnkdClmsRecvDt() {
		return lnkdClmsRecvDt;
	}

	public void setLnkdClmsRecvDt(Integer lnkdClmsRecvDt) {
		this.lnkdClmsRecvDt = lnkdClmsRecvDt;
	}

	public String getInteraction() {
		return interaction;
	}

	public void setInteraction(String interaction) {
		this.interaction = interaction;
	}

	public String getInqTrackingId() {
		return inqTrackingId;
	}

	public void setInqTrackingId(String inqTrackingId) {
		this.inqTrackingId = inqTrackingId;
	}

	public String getClmSrvcInqCount() {
		return clmSrvcInqCount;
	}

	public void setClmSrvcInqCount(String clmSrvcInqCount) {
		this.clmSrvcInqCount = clmSrvcInqCount;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static ClaimInquiryRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		ClaimInquiryRecords claimInqu = null;
		claimInqu = mapper.readValue(jsonString, ClaimInquiryRecords.class);
		return claimInqu;
	}

}
