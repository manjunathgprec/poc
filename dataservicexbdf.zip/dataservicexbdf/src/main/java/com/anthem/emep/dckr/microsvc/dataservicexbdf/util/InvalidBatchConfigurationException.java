package com.anthem.emep.dckr.microsvc.dataservicexbdf.util;

public class InvalidBatchConfigurationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidBatchConfigurationException(String message) {
		super(message);
	}

}
