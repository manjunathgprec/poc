package com.anthem.emep.dckr.microsvc.dataservicexbdf.service;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.SearchCriteria;

public interface IProcessor {

	public void process(SearchCriteria SearchCriteria);

}
