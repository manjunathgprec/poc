package com.anthem.emep.dckr.microsvc.dataservicexbdf.repository;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.PersonProxyRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.PrsnMemberKeys;

@Repository
public class PersonProxyRecordsRepository {

	private static final Logger logger = LoggerFactory.getLogger(PersonProxyRecordsRepository.class);

	private static final String GUID = "metaRecLtstUpdtGuid";

	@Autowired
	private MongoTemplate mongoTemplate;

	public PersonProxyRecords fetchLatestehubProxyRltn() {
		logger.info("Inside fetchLatestehubProxyRltn");
		Query query = new Query();
		query.limit(1);
		query.with(new Sort(Sort.Direction.DESC, "metaRecLtstUpdtDtm"));
		PersonProxyRecords data = mongoTemplate.findOne(query, PersonProxyRecords.class);
		return data;
	}

	public PersonProxyRecords find(String guid) {
		Query query = new Query();
		query.addCriteria(Criteria.where(GUID).is(guid));
		PersonProxyRecords data = mongoTemplate.findOne(query, PersonProxyRecords.class);
		return data;
	}

	public boolean isDataModified(PersonProxyRecords entity) {
		boolean isEqualsObj = true;

		PersonProxyRecords data = this.find(entity.getMetaRecLtstUpdtGuid());
		
		if(data == null) {
			return false;
		}

		List<PrsnMemberKeys> personMemberKeys = data.getPrsnMemberKeys();
		List<PrsnMemberKeys> memberKeys = entity.getPrsnMemberKeys();

		if (!StringUtils.equals(entity.getPkeyCsPersonId(), data.getPkeyCsPersonId())
				&& !entity.getPrsnEhubPrsnId().equals(data.getPrsnEhubPrsnId())
				&& !StringUtils.equals(entity.getPrsnMcid(), data.getPrsnMcid())) {
			isEqualsObj = false;

		}
		if (isEqualsObj) {
			for (PrsnMemberKeys memberKeyEntity : personMemberKeys) {
				for (PrsnMemberKeys memberKeyData : memberKeys) {
					//isEqualsObj = comparePersonKeys(memberKeyEntity, memberKeyData);
				}
			}
		}

		return isEqualsObj;
	}

	/*private boolean comparePersonKeys(PrsnMemberKeys entity, PrsnMemberKeys data) {
		if (!StringUtils.equals(entity.getPrsnMemberKey().getMbr4Pkey(), data.getPrsnMemberKey().getMbr4Pkey()))
			return false;
		else if (!StringUtils.equals(entity.getPrsnMemberKey().getMbrDgtlEnrlmntRel(), data.getPrsnMemberKey().getMbrDgtlEnrlmntRel()))
			return false;
		else if (!StringUtils.equals(entity.getPrsnMemberKey().getMbrEhubid(), data.getPrsnMemberKey().getMbrEhubid()))
			return false;
		else if (!StringUtils.equals(entity.getPrsnMemberKey().getMbrHashkey(), data.getPrsnMemberKey().getMbrHashkey()))
			return false;
		else if (!StringUtils.equals(entity.getPrsnMemberKey().getMbrHcid(), data.getPrsnMemberKey().getMbrHcid()))
			return false;
		else if (!StringUtils.equals(entity.getPrsnMemberKey().getMbrSubscriber(), data.getPrsnMemberKey().getMbrSubscriber()))
			return false;

		return true;

	}*/

}
