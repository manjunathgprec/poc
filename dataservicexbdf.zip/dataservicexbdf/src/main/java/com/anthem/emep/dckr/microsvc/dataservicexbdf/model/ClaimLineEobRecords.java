package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * POJO class to represent the state of soa-clm-dtl-line-eob-seg-v01
 * 
 * @author ag59866
 *
 */
@Document(collection = EventsModelConstants.CLAIMLINEEOB_COLLECION)
public class ClaimLineEobRecords extends BaseEntity {

	private String pkeyClmEobRefNo;
	private String clmId;
	private String clmLineEobLineNbr;
	private Double clmLineEobSeqNbr;
	private String clmLineEobItmCde;
	private String clmLineEobSrvcExplntnCd;
	private Double clmLineEobSrvcExplntnAmt;

	public String getPkeyClmEobRefNo() {
		return pkeyClmEobRefNo;
	}

	public void setPkeyClmEobRefNo(String pkeyClmEobRefNo) {
		this.pkeyClmEobRefNo = pkeyClmEobRefNo;
	}

	public String getClmId() {
		return clmId;
	}

	public void setClmId(String clmId) {
		this.clmId = clmId;
	}

	public String getClmLineEobLineNbr() {
		return clmLineEobLineNbr;
	}

	public void setClmLineEobLineNbr(String clmLineEobLineNbr) {
		this.clmLineEobLineNbr = clmLineEobLineNbr;
	}

	public Double getClmLineEobSeqNbr() {
		return clmLineEobSeqNbr;
	}

	public void setClmLineEobSeqNbr(Double clmLineEobSeqNbr) {
		this.clmLineEobSeqNbr = clmLineEobSeqNbr;
	}

	public String getClmLineEobItmCde() {
		return clmLineEobItmCde;
	}

	public void setClmLineEobItmCde(String clmLineEobItmCde) {
		this.clmLineEobItmCde = clmLineEobItmCde;
	}

	public String getClmLineEobSrvcExplntnCd() {
		return clmLineEobSrvcExplntnCd;
	}

	public void setClmLineEobSrvcExplntnCd(String clmLineEobSrvcExplntnCd) {
		this.clmLineEobSrvcExplntnCd = clmLineEobSrvcExplntnCd;
	}

	public Double getClmLineEobSrvcExplntnAmt() {
		return clmLineEobSrvcExplntnAmt;
	}

	public void setClmLineEobSrvcExplntnAmt(Double clmLineEobSrvcExplntnAmt) {
		this.clmLineEobSrvcExplntnAmt = clmLineEobSrvcExplntnAmt;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static ClaimLineEobRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		ClaimLineEobRecords claimLineEob = null;
		claimLineEob = mapper.readValue(jsonString, ClaimLineEobRecords.class);
		return claimLineEob;
	}

}
