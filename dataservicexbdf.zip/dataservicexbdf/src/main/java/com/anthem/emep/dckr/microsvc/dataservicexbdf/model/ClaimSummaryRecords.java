package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * POJO class to represent the state of soa-clm-sum-seg-v01
 * 
 * @author ag59866
 *
 */
@Document(collection = EventsModelConstants.CLAIMSUMMARY_COLLECION)
public class ClaimSummaryRecords extends BaseEntity {

	private String pkeyClmId;
	private String skeyMbr4PartRefNo;
	private String clmMbrSorCd;
	private String clmMbrGrpNbr;
	private String clmMbrIdnSubId;
	private Double clmMbrSqncNbr;
	private String clmId;
	private Double clmAdjstmntNbr;
	private String clmItemCd;
	private String clmProvFullNm;
	private String clmProvScndryNm;
	private String clmProvIdTypeCd;
	private Double clmDdctblAmt;
	private Double clmTotlDdctblAmt;
	private Double clmTotlDdctblMbrAmt;
	private Double clmTotlDdctblFmlyAmt;
	private Double clmTotlBilldChrgAmt;
	private Double clmTotlAlwdAmt;
	private Double clmTotlPaidAmt;
	private Double clmTotlCoInsuAmt;
	private Double clmTotlCoPaymntAmt;
	private Double clmTotlNonElgAmt;
	private Double clmTotlMbrLiablAmt;
	private Double clmTotlPartBAprvdAmt;
	private Double clmTotlPartBPaidAmt;
	private Double clmTotlProvWoAmt;
	private Integer clmSrvcInqCount;
	private Integer clmDtlCntr;
	private Integer clmEobCntr;
	private Integer clmLstUpdtDt;
	private Double clmStrtDt;
	private Double clmEndDt;
	private String clmSttsCd;
	private String clmProdGrpId;
	private String clmPrimNetCde;

	public String getPkeyClmId() {
		return pkeyClmId;
	}

	public void setPkeyClmId(String pkeyClmId) {
		this.pkeyClmId = pkeyClmId;
	}

	public String getSkeyMbr4PartRefNo() {
		return skeyMbr4PartRefNo;
	}

	public void setSkeyMbr4PartRefNo(String skeyMbr4PartRefNo) {
		this.skeyMbr4PartRefNo = skeyMbr4PartRefNo;
	}

	public String getClmMbrSorCd() {
		return clmMbrSorCd;
	}

	public void setClmMbrSorCd(String clmMbrSorCd) {
		this.clmMbrSorCd = clmMbrSorCd;
	}

	public String getClmMbrGrpNbr() {
		return clmMbrGrpNbr;
	}

	public void setClmMbrGrpNbr(String clmMbrGrpNbr) {
		this.clmMbrGrpNbr = clmMbrGrpNbr;
	}

	public String getClmMbrIdnSubId() {
		return clmMbrIdnSubId;
	}

	public void setClmMbrIdnSubId(String clmMbrIdnSubId) {
		this.clmMbrIdnSubId = clmMbrIdnSubId;
	}

	public Double getClmMbrSqncNbr() {
		return clmMbrSqncNbr;
	}

	public void setClmMbrSqncNbr(Double clmMbrSqncNbr) {
		this.clmMbrSqncNbr = clmMbrSqncNbr;
	}

	public String getClmId() {
		return clmId;
	}

	public void setClmId(String clmId) {
		this.clmId = clmId;
	}

	public Double getClmAdjstmntNbr() {
		return clmAdjstmntNbr;
	}

	public void setClmAdjstmntNbr(Double clmAdjstmntNbr) {
		this.clmAdjstmntNbr = clmAdjstmntNbr;
	}

	public String getClmItemCd() {
		return clmItemCd;
	}

	public void setClmItemCd(String clmItemCd) {
		this.clmItemCd = clmItemCd;
	}

	public String getClmProvFullNm() {
		return clmProvFullNm;
	}

	public void setClmProvFullNm(String clmProvFullNm) {
		this.clmProvFullNm = clmProvFullNm;
	}

	public String getClmProvScndryNm() {
		return clmProvScndryNm;
	}

	public void setClmProvScndryNm(String clmProvScndryNm) {
		this.clmProvScndryNm = clmProvScndryNm;
	}

	public String getClmProvIdTypeCd() {
		return clmProvIdTypeCd;
	}

	public void setClmProvIdTypeCd(String clmProvIdTypeCd) {
		this.clmProvIdTypeCd = clmProvIdTypeCd;
	}

	public Double getClmDdctblAmt() {
		return clmDdctblAmt;
	}

	public void setClmDdctblAmt(Double clmDdctblAmt) {
		this.clmDdctblAmt = clmDdctblAmt;
	}

	public Double getClmTotlDdctblAmt() {
		return clmTotlDdctblAmt;
	}

	public void setClmTotlDdctblAmt(Double clmTotlDdctblAmt) {
		this.clmTotlDdctblAmt = clmTotlDdctblAmt;
	}

	public Double getClmTotlDdctblMbrAmt() {
		return clmTotlDdctblMbrAmt;
	}

	public void setClmTotlDdctblMbrAmt(Double clmTotlDdctblMbrAmt) {
		this.clmTotlDdctblMbrAmt = clmTotlDdctblMbrAmt;
	}

	public Double getClmTotlDdctblFmlyAmt() {
		return clmTotlDdctblFmlyAmt;
	}

	public void setClmTotlDdctblFmlyAmt(Double clmTotlDdctblFmlyAmt) {
		this.clmTotlDdctblFmlyAmt = clmTotlDdctblFmlyAmt;
	}

	public Double getClmTotlBilldChrgAmt() {
		return clmTotlBilldChrgAmt;
	}

	public void setClmTotlBilldChrgAmt(Double clmTotlBilldChrgAmt) {
		this.clmTotlBilldChrgAmt = clmTotlBilldChrgAmt;
	}

	public Double getClmTotlAlwdAmt() {
		return clmTotlAlwdAmt;
	}

	public void setClmTotlAlwdAmt(Double clmTotlAlwdAmt) {
		this.clmTotlAlwdAmt = clmTotlAlwdAmt;
	}

	public Double getClmTotlPaidAmt() {
		return clmTotlPaidAmt;
	}

	public void setClmTotlPaidAmt(Double clmTotlPaidAmt) {
		this.clmTotlPaidAmt = clmTotlPaidAmt;
	}

	public Double getClmTotlCoInsuAmt() {
		return clmTotlCoInsuAmt;
	}

	public void setClmTotlCoInsuAmt(Double clmTotlCoInsuAmt) {
		this.clmTotlCoInsuAmt = clmTotlCoInsuAmt;
	}

	public Double getClmTotlCoPaymntAmt() {
		return clmTotlCoPaymntAmt;
	}

	public void setClmTotlCoPaymntAmt(Double clmTotlCoPaymntAmt) {
		this.clmTotlCoPaymntAmt = clmTotlCoPaymntAmt;
	}

	public Double getClmTotlNonElgAmt() {
		return clmTotlNonElgAmt;
	}

	public void setClmTotlNonElgAmt(Double clmTotlNonElgAmt) {
		this.clmTotlNonElgAmt = clmTotlNonElgAmt;
	}

	public Double getClmTotlMbrLiablAmt() {
		return clmTotlMbrLiablAmt;
	}

	public void setClmTotlMbrLiablAmt(Double clmTotlMbrLiablAmt) {
		this.clmTotlMbrLiablAmt = clmTotlMbrLiablAmt;
	}

	public Double getClmTotlPartBAprvdAmt() {
		return clmTotlPartBAprvdAmt;
	}

	public void setClmTotlPartBAprvdAmt(Double clmTotlPartBAprvdAmt) {
		this.clmTotlPartBAprvdAmt = clmTotlPartBAprvdAmt;
	}

	public Double getClmTotlPartBPaidAmt() {
		return clmTotlPartBPaidAmt;
	}

	public void setClmTotlPartBPaidAmt(Double clmTotlPartBPaidAmt) {
		this.clmTotlPartBPaidAmt = clmTotlPartBPaidAmt;
	}

	public Double getClmTotlProvWoAmt() {
		return clmTotlProvWoAmt;
	}

	public void setClmTotlProvWoAmt(Double clmTotlProvWoAmt) {
		this.clmTotlProvWoAmt = clmTotlProvWoAmt;
	}

	public Integer getClmSrvcInqCount() {
		return clmSrvcInqCount;
	}

	public void setClmSrvcInqCount(Integer clmSrvcInqCount) {
		this.clmSrvcInqCount = clmSrvcInqCount;
	}

	public Integer getClmDtlCntr() {
		return clmDtlCntr;
	}

	public void setClmDtlCntr(Integer clmDtlCntr) {
		this.clmDtlCntr = clmDtlCntr;
	}

	public Integer getClmEobCntr() {
		return clmEobCntr;
	}

	public void setClmEobCntr(Integer clmEobCntr) {
		this.clmEobCntr = clmEobCntr;
	}

	public Integer getClmLstUpdtDt() {
		return clmLstUpdtDt;
	}

	public void setClmLstUpdtDt(Integer clmLstUpdtDt) {
		this.clmLstUpdtDt = clmLstUpdtDt;
	}

	public Double getClmStrtDt() {
		return clmStrtDt;
	}

	public void setClmStrtDt(Double clmStrtDt) {
		this.clmStrtDt = clmStrtDt;
	}

	public Double getClmEndDt() {
		return clmEndDt;
	}

	public void setClmEndDt(Double clmEndDt) {
		this.clmEndDt = clmEndDt;
	}

	public String getClmSttsCd() {
		return clmSttsCd;
	}

	public void setClmSttsCd(String clmSttsCd) {
		this.clmSttsCd = clmSttsCd;
	}

	public String getClmProdGrpId() {
		return clmProdGrpId;
	}

	public void setClmProdGrpId(String clmProdGrpId) {
		this.clmProdGrpId = clmProdGrpId;
	}

	public String getClmPrimNetCde() {
		return clmPrimNetCde;
	}

	public void setClmPrimNetCde(String clmPrimNetCde) {
		this.clmPrimNetCde = clmPrimNetCde;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static ClaimSummaryRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		ClaimSummaryRecords claimSum = null;
		claimSum = mapper.readValue(jsonString, ClaimSummaryRecords.class);
		return claimSum;
	}

}
