package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimLineDetailRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;

public class ClaimLineDetailRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(ClaimLineDetailRecordsRowMapper.class);

	private String messageType;

	public ClaimLineDetailRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public ClaimLineDetailRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		ClaimLineDetailRecords claimLineDetailRecords = new ClaimLineDetailRecords();

		// Meta fields mapping
		claimLineDetailRecords.setMetaMsgType(messageType);
		claimLineDetailRecords.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		claimLineDetailRecords.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		claimLineDetailRecords.setMetaRecLtstUpdtGuid(rs.getString("guid"));
        
		claimLineDetailRecords.setClmId(StringUtils.trimWhitespace(rs.getString("GNCHIIOS_HCLM_DCN_CC" +"-"+ "GNCHIIOS_HCLM_DCN")));
		claimLineDetailRecords.setClmLineNbr(StringUtils.trimWhitespace(rs.getString("DDC_DTL_LNE_NBR")));
		claimLineDetailRecords.setClmLineSeqNbr(rs.getDouble("GNCHIIOS_HCLM_SEQ_NBR"));
		claimLineDetailRecords.setClmLineItmCde(StringUtils.trimWhitespace(rs.getString("GNCHIIOS_HCLM_ITM_CDE")));
		claimLineDetailRecords.setClmLineSrvcStrtDt(rs.getDouble("DDC_DTL_SVC_FROM_DTE"));
		claimLineDetailRecords.setClmLineSrvcEndDt(rs.getDouble("DDC_DTL_SVC_THRU_DTE"));
		claimLineDetailRecords.setClmLinePlaceOfSrvcCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_PT_CDE")));
		claimLineDetailRecords.setClmLineHlthSrvcCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_PRCDR_CDE")));
		claimLineDetailRecords.setClmLineBilldChrgAmt(rs.getDouble("DDC_DTL_BLLD_AMT"));
		claimLineDetailRecords.setClmLineTosCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_TT_CDE")));
		claimLineDetailRecords.setClmLineSvcCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_SVC_CDE_1_3")));
		claimLineDetailRecords.setClmLineInzipRadInd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_INZIP_RADIUS_IND")));
		claimLineDetailRecords.setClmLineMbrCntrctCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_MBR_CONTR_CDE")));
		claimLineDetailRecords.setClmLineMbrCntrctType(StringUtils.trimWhitespace(rs.getString("DDC_DTL_MBR_CONTR_TYPE")));
		claimLineDetailRecords.setClmLineBenfYrContrEfctvDt(rs.getDouble("DDC_DTL_BNFT_YR_CONTR_EFF_DTE"));
		claimLineDetailRecords.setClmLineAlwdAmt(rs.getDouble("DDC_DTL_ELIG_EXPSN_AMT"));
		claimLineDetailRecords.setClmLineRsnblCutbkAmt(rs.getDouble("DDC_DTL_RSNBL_CUTBK_AMT"));
		claimLineDetailRecords.setClmLineNonCvrdAmt(rs.getDouble("DDC_DTL_NOT_COVD_AMT"));
		claimLineDetailRecords.setClmLinePaidAmt(rs.getDouble("DDC_DTL_PAY_AMT"));
		claimLineDetailRecords.setClmLineNonElgSavngAmt(rs.getDouble("DDC_DTL_NOT_ELIG_SVNGS_AMT"));
		claimLineDetailRecords.setClmLineTypeCde(StringUtils.trimWhitespace(rs.getString("DDC_DTL_LNE_TYPE_CDE")));
		claimLineDetailRecords.setClmLinePrtFlg(StringUtils.trimWhitespace(rs.getString("DDC_DTL_LNE_PRT_FLG")));
		claimLineDetailRecords.setClmLineRejTypeCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_REJ_TYPE_CDE")));
		claimLineDetailRecords.setClmLineRejTypeAmt(rs.getDouble("DDC_DTL_REJ_TYPE_AMT"));
		claimLineDetailRecords.setClmLineDeductTypeCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_DEDUCT_TYPE_CDE")));
		claimLineDetailRecords.setClmLineDdctblAmt(rs.getDouble("DDC_DTL_DEDUCT_TYPE_AMT"));
		claimLineDetailRecords.setClmLineCoPayTypeCd(StringUtils.trimWhitespace(rs.getString("DDC_DTL_COPAY_TYPE_CDE")));
		claimLineDetailRecords.setClmLineCoPaymntAmt(rs.getDouble("DDC_DTL_COPAY_TYPE_AMT"));
		claimLineDetailRecords.setClmLineCoInsuAmt(rs.getDouble(""));
		claimLineDetailRecords.setClmLineWriteoffTypeAmt(rs.getDouble("DDC_DTL_WRITEOFF_TYPE_AMT"));
		claimLineDetailRecords.setClmLinePartBAprvdAmt(rs.getDouble("DDC_DTL_PART_B_APRVD_AMT"));
		claimLineDetailRecords.setClmLinePartBPaidAmt(rs.getDouble("DDC_DTL_PART_B_PAID_AMT"));
		claimLineDetailRecords.setClmLinePartBCoInsAmt(rs.getDouble("DDC_DTL_PART_B_COINS_AMT"));
		//Primary key
		claimLineDetailRecords.setPkeyClmLineRefNo(claimLineDetailRecords.getClmId() +"-"+ claimLineDetailRecords.getClmLineNbr()); 
		
		return claimLineDetailRecords;
	}

}
