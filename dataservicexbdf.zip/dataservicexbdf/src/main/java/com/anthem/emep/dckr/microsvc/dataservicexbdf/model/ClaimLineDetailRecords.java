package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * POJO class to represent the state of soa-clm-dtl-line-seg-v01
 * 
 * @author ag59866
 *
 */
@Document(collection = EventsModelConstants.CLAIMLINEDETAIL_COLLECION)
public class ClaimLineDetailRecords extends BaseEntity {

	private String pkeyClmLineRefNo;
	private String clmId;
	private Double clmLineSeqNbr;
	private String clmLineItmCde;
	private String clmLineNbr;
	private Double clmLineSrvcStrtDt;
	private Double clmLineSrvcEndDt;
	private String clmLinePlaceOfSrvcCd;
	private String clmLineHlthSrvcCd;
	private Double clmLineBilldChrgAmt;
	private String clmLineTosCd;
	private String clmLineSvcCd;
	private String clmLineInzipRadInd;
	private String clmLineMbrCntrctCd;
	private String clmLineMbrCntrctType;
	private Double clmLineBenfYrContrEfctvDt;
	private Double clmLineAlwdAmt;
	private Double clmLineRsnblCutbkAmt;
	private Double clmLineNonCvrdAmt;
	private Double clmLinePaidAmt;
	private Double clmLineNonElgSavngAmt;
	private String clmLineTypeCde;
	private String clmLinePrtFlg;
	private String clmLineRejTypeCd;
	private Double clmLineRejTypeAmt;
	private String clmLineDeductTypeCd;
	private Double clmLineDdctblAmt;
	private String clmLineCoPayTypeCd;
	private Double clmLineCoPaymntAmt;
	private Double clmLineCoInsuAmt;
	private String clmLineWriteoffTypeCd;
	private Double clmLineWriteoffTypeAmt;
	private Double clmLinePartBAprvdAmt;
	private Double clmLinePartBPaidAmt;
	private Double clmLinePartBCoInsAmt;

	public String getPkeyClmLineRefNo() {
		return pkeyClmLineRefNo;
	}

	public void setPkeyClmLineRefNo(String pkeyClmLineRefNo) {
		this.pkeyClmLineRefNo = pkeyClmLineRefNo;
	}

	public String getClmId() {
		return clmId;
	}

	public void setClmId(String clmId) {
		this.clmId = clmId;
	}

	public Double getClmLineSeqNbr() {
		return clmLineSeqNbr;
	}

	public void setClmLineSeqNbr(Double clmLineSeqNbr) {
		this.clmLineSeqNbr = clmLineSeqNbr;
	}

	public String getClmLineItmCde() {
		return clmLineItmCde;
	}

	public void setClmLineItmCde(String clmLineItmCde) {
		this.clmLineItmCde = clmLineItmCde;
	}

	public String getClmLineNbr() {
		return clmLineNbr;
	}

	public void setClmLineNbr(String clmLineNbr) {
		this.clmLineNbr = clmLineNbr;
	}

	public Double getClmLineSrvcStrtDt() {
		return clmLineSrvcStrtDt;
	}

	public void setClmLineSrvcStrtDt(Double clmLineSrvcStrtDt) {
		this.clmLineSrvcStrtDt = clmLineSrvcStrtDt;
	}

	public Double getClmLineSrvcEndDt() {
		return clmLineSrvcEndDt;
	}

	public void setClmLineSrvcEndDt(Double clmLineSrvcEndDt) {
		this.clmLineSrvcEndDt = clmLineSrvcEndDt;
	}

	public String getClmLinePlaceOfSrvcCd() {
		return clmLinePlaceOfSrvcCd;
	}

	public void setClmLinePlaceOfSrvcCd(String clmLinePlaceOfSrvcCd) {
		this.clmLinePlaceOfSrvcCd = clmLinePlaceOfSrvcCd;
	}

	public String getClmLineHlthSrvcCd() {
		return clmLineHlthSrvcCd;
	}

	public void setClmLineHlthSrvcCd(String clmLineHlthSrvcCd) {
		this.clmLineHlthSrvcCd = clmLineHlthSrvcCd;
	}

	public Double getClmLineBilldChrgAmt() {
		return clmLineBilldChrgAmt;
	}

	public void setClmLineBilldChrgAmt(Double clmLineBilldChrgAmt) {
		this.clmLineBilldChrgAmt = clmLineBilldChrgAmt;
	}

	public String getClmLineTosCd() {
		return clmLineTosCd;
	}

	public void setClmLineTosCd(String clmLineTosCd) {
		this.clmLineTosCd = clmLineTosCd;
	}

	public String getClmLineSvcCd() {
		return clmLineSvcCd;
	}

	public void setClmLineSvcCd(String clmLineSvcCd) {
		this.clmLineSvcCd = clmLineSvcCd;
	}

	public String getClmLineInzipRadInd() {
		return clmLineInzipRadInd;
	}

	public void setClmLineInzipRadInd(String clmLineInzipRadInd) {
		this.clmLineInzipRadInd = clmLineInzipRadInd;
	}

	public String getClmLineMbrCntrctCd() {
		return clmLineMbrCntrctCd;
	}

	public void setClmLineMbrCntrctCd(String clmLineMbrCntrctCd) {
		this.clmLineMbrCntrctCd = clmLineMbrCntrctCd;
	}

	public String getClmLineMbrCntrctType() {
		return clmLineMbrCntrctType;
	}

	public void setClmLineMbrCntrctType(String clmLineMbrCntrctType) {
		this.clmLineMbrCntrctType = clmLineMbrCntrctType;
	}

	public Double getClmLineBenfYrContrEfctvDt() {
		return clmLineBenfYrContrEfctvDt;
	}

	public void setClmLineBenfYrContrEfctvDt(Double clmLineBenfYrContrEfctvDt) {
		this.clmLineBenfYrContrEfctvDt = clmLineBenfYrContrEfctvDt;
	}

	public Double getClmLineAlwdAmt() {
		return clmLineAlwdAmt;
	}

	public void setClmLineAlwdAmt(Double clmLineAlwdAmt) {
		this.clmLineAlwdAmt = clmLineAlwdAmt;
	}

	public Double getClmLineRsnblCutbkAmt() {
		return clmLineRsnblCutbkAmt;
	}

	public void setClmLineRsnblCutbkAmt(Double clmLineRsnblCutbkAmt) {
		this.clmLineRsnblCutbkAmt = clmLineRsnblCutbkAmt;
	}

	public Double getClmLineNonCvrdAmt() {
		return clmLineNonCvrdAmt;
	}

	public void setClmLineNonCvrdAmt(Double clmLineNonCvrdAmt) {
		this.clmLineNonCvrdAmt = clmLineNonCvrdAmt;
	}

	public Double getClmLinePaidAmt() {
		return clmLinePaidAmt;
	}

	public void setClmLinePaidAmt(Double clmLinePaidAmt) {
		this.clmLinePaidAmt = clmLinePaidAmt;
	}

	public Double getClmLineNonElgSavngAmt() {
		return clmLineNonElgSavngAmt;
	}

	public void setClmLineNonElgSavngAmt(Double clmLineNonElgSavngAmt) {
		this.clmLineNonElgSavngAmt = clmLineNonElgSavngAmt;
	}

	public String getClmLineTypeCde() {
		return clmLineTypeCde;
	}

	public void setClmLineTypeCde(String clmLineTypeCde) {
		this.clmLineTypeCde = clmLineTypeCde;
	}

	public String getClmLinePrtFlg() {
		return clmLinePrtFlg;
	}

	public void setClmLinePrtFlg(String clmLinePrtFlg) {
		this.clmLinePrtFlg = clmLinePrtFlg;
	}

	public String getClmLineRejTypeCd() {
		return clmLineRejTypeCd;
	}

	public void setClmLineRejTypeCd(String clmLineRejTypeCd) {
		this.clmLineRejTypeCd = clmLineRejTypeCd;
	}

	public Double getClmLineRejTypeAmt() {
		return clmLineRejTypeAmt;
	}

	public void setClmLineRejTypeAmt(Double clmLineRejTypeAmt) {
		this.clmLineRejTypeAmt = clmLineRejTypeAmt;
	}

	public String getClmLineDeductTypeCd() {
		return clmLineDeductTypeCd;
	}

	public void setClmLineDeductTypeCd(String clmLineDeductTypeCd) {
		this.clmLineDeductTypeCd = clmLineDeductTypeCd;
	}

	public Double getClmLineDdctblAmt() {
		return clmLineDdctblAmt;
	}

	public void setClmLineDdctblAmt(Double clmLineDdctblAmt) {
		this.clmLineDdctblAmt = clmLineDdctblAmt;
	}

	public String getClmLineCoPayTypeCd() {
		return clmLineCoPayTypeCd;
	}

	public void setClmLineCoPayTypeCd(String clmLineCoPayTypeCd) {
		this.clmLineCoPayTypeCd = clmLineCoPayTypeCd;
	}

	public Double getClmLineCoPaymntAmt() {
		return clmLineCoPaymntAmt;
	}

	public void setClmLineCoPaymntAmt(Double clmLineCoPaymntAmt) {
		this.clmLineCoPaymntAmt = clmLineCoPaymntAmt;
	}

	public Double getClmLineCoInsuAmt() {
		return clmLineCoInsuAmt;
	}

	public void setClmLineCoInsuAmt(Double clmLineCoInsuAmt) {
		this.clmLineCoInsuAmt = clmLineCoInsuAmt;
	}

	public String getClmLineWriteoffTypeCd() {
		return clmLineWriteoffTypeCd;
	}

	public void setClmLineWriteoffTypeCd(String clmLineWriteoffTypeCd) {
		this.clmLineWriteoffTypeCd = clmLineWriteoffTypeCd;
	}

	public Double getClmLineWriteoffTypeAmt() {
		return clmLineWriteoffTypeAmt;
	}

	public void setClmLineWriteoffTypeAmt(Double clmLineWriteoffTypeAmt) {
		this.clmLineWriteoffTypeAmt = clmLineWriteoffTypeAmt;
	}

	public Double getClmLinePartBAprvdAmt() {
		return clmLinePartBAprvdAmt;
	}

	public void setClmLinePartBAprvdAmt(Double clmLinePartBAprvdAmt) {
		this.clmLinePartBAprvdAmt = clmLinePartBAprvdAmt;
	}

	public Double getClmLinePartBPaidAmt() {
		return clmLinePartBPaidAmt;
	}

	public void setClmLinePartBPaidAmt(Double clmLinePartBPaidAmt) {
		this.clmLinePartBPaidAmt = clmLinePartBPaidAmt;
	}

	public Double getClmLinePartBCoInsAmt() {
		return clmLinePartBCoInsAmt;
	}

	public void setClmLinePartBCoInsAmt(Double clmLinePartBCoInsAmt) {
		this.clmLinePartBCoInsAmt = clmLinePartBCoInsAmt;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static ClaimLineDetailRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		ClaimLineDetailRecords claimLineDtl = null;
		claimLineDtl = mapper.readValue(jsonString, ClaimLineDetailRecords.class);
		return claimLineDtl;
	}

}
