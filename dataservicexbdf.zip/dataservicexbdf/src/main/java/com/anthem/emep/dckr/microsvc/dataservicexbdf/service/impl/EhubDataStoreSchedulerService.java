package com.anthem.emep.dckr.microsvc.dataservicexbdf.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.ApplicationGlobalProperties;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.LastProcessedDate;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.SearchCriteria;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.ClaimEOBLookupRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.ClaimInquiryRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.ClaimLineDetailRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.ClaimLineEOBRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.ClaimPaymentRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.ClaimSummaryRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.MemberCaseRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.MemberNetworkRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.MembershipRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper.PersonProxyRecordsRowMapper;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.service.IProcessor;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.task.EhubDataStoreTask;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.InvalidBatchConfigurationException;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.TaskTypes;

@Component
public class EhubDataStoreSchedulerService {

	private Logger logger = LoggerFactory.getLogger(EhubDataStoreSchedulerService.class);

	@Autowired
	private ExecutorService executorService;

	@Autowired
	private EhubDataLastProcessedDateReader reader;

	@Autowired
	private IProcessor processor;

	@Autowired
	private ApplicationGlobalProperties prop;

	private LastProcessedDate lastProcessedDate;

	/**
	 * This method will trigger as scheduler method for processing Hive table data
	 * on the real time manner
	 */
	public void call() {

		try {

			prop.setJobStartDate("20191213");
			prop.setJobEndDate("20200226");

			// prop.setJobStartDate(null);

			// Cover two scenario's start date with end date / start date without end date
			if (StringUtils.isNotEmpty(prop.getJobStartDate())) {
				boolean isValidStartDate = DateUtil.isValid(prop.getJobStartDate());
				boolean isValidEndDate = Boolean.TRUE;

				if (StringUtils.isNotEmpty(prop.getJobEndDate())) {
					isValidEndDate = DateUtil.isValid(prop.getJobEndDate());
				} else {
					// Initialize end date with current date if no end date configured
					prop.setJobEndDate(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
					logger.error(" No end date configured and process the records with current time :: "
							+ prop.getJobEndDate());
				}

				String message = "start/end date from the configuration file to process the job with jobStartDate ["
						+ prop.getJobStartDate() + "] jobEndDate [" + prop.getJobEndDate() + "]";
				if (!isValidStartDate || !isValidEndDate) {
					String errorMessage = "Invalid " + message;
					throw new InvalidBatchConfigurationException(errorMessage);
				}
				logger.info(message);
				// Cover two scenario's No start date with end date / No start date without end
				// date
			} else if (StringUtils.isEmpty(prop.getJobStartDate())) {

				if (StringUtils.isNotEmpty(prop.getJobEndDate())) {
					if (!DateUtil.isValid(prop.getJobEndDate())) {
						String errorMessage = "Invalid start date from the configuration file to process the job with jobStartDate ["
								+ prop.getJobStartDate() + "]";
						throw new InvalidBatchConfigurationException(errorMessage);
					}

				} else {
					// Initialize end date with current date if no end date configured
					prop.setJobEndDate(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
					logger.error("No end date configured and process the records with current time :: "
							+ prop.getJobEndDate());

				}
				// Fetch last processed record from MongoDB
				lastProcessedDate = reader.loadLastProcessedDate();
			}

			List<Runnable> tasks = new ArrayList<>();
			
			// We should be adding tasks based on the requirement for Hive table data loading
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.PersonProxyRecords), processor));
			tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.MemberCaseRecords), processor));
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.MembershipRecords), processor));
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.MemberNetworkRecords), processor));
			// tasks.add(new  EhubDataStoreTask(prepareSearchCriteria(TaskTypes.ClaimSummaryRecords), processor));
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.ClaimLineDetailRecords), processor));
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.ClaimLineEOBRecords), processor));
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.ClaimPaymentRecords), processor));
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.ClaimEOBLookupRecords), processor)); 
			// tasks.add(new EhubDataStoreTask(prepareSearchCriteria(TaskTypes.ClaimInquiryRecords), processor));
		 

			for (Runnable task : tasks) {
				executorService.submit(task);
			}

			executorService.shutdown();
		} catch (Exception exception) {
			logger.error(exception.getMessage());
		}

	}

	/**
	 * Method to prepare search criteria object based on the task type requested
	 * 
	 * @param task,
	 *            the task type to represent type of table
	 * @return SearchCriteria, the specific SearchCriteria object having date range
	 *         and table queries for the TaskType
	 */
	private SearchCriteria prepareSearchCriteria(TaskTypes task) {
		SearchCriteria criteria = new SearchCriteria();
		criteria.setPageSize(prop.getPageSize());
		criteria.setStartDate(prop.getJobStartDate());
		criteria.setEndDate(prop.getJobEndDate());

		switch (task) {
		case PersonProxyRecords:
			criteria.setTableName(prop.getPersonProxyRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getPersonProxyRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getPersonProxyRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getPersonProxyRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getPersonProxyRecordsDataQuery());
			criteria.setMapper(new PersonProxyRecordsRowMapper(prop.getPersonProxyRecordsMsgType()));
			break;
		case MemberCaseRecords:
			criteria.setTableName(prop.getMemberCaseRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getMemberCaseRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getMemberCaseRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getMemberCaseRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getMemberCaseRecordsDataQuery());
			criteria.setMapper(new MemberCaseRecordsRowMapper(prop.getMemberCaseRecordsMsgType()));
			break;
		case MembershipRecords:
			criteria.setTableName(prop.getMembershipRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getMembershipRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getMembershipRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getMembershipRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getMembershipRecordsDataQuery());
			criteria.setMapper(new MembershipRecordsRowMapper(prop.getMembershipRecordsMsgType()));
			break;
		case MemberNetworkRecords:
			criteria.setTableName(prop.getMemberNetworkRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getMemberNetworkRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getMemberNetworkRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getMemberNetworkRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getMemberNetworkRecordsDataQuery());
			criteria.setMapper(new MemberNetworkRecordsRowMapper(prop.getMemberNetworkRecordsMsgType()));
			break;
		case ClaimSummaryRecords:
			criteria.setTableName(prop.getClaimSummaryRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getClaimSummaryRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getClaimSummaryRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getClaimSummaryRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getClaimSummaryRecordsDataQuery());
			criteria.setMapper(new ClaimSummaryRecordsRowMapper(prop.getClaimSummaryRecordsMsgType()));
			break;
		case ClaimLineDetailRecords:
			criteria.setTableName(prop.getClaimLineDetailRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getClaimLineDetailRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getClaimLineDetailRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getClaimLineDetailRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getClaimLineDetailRecordsDataQuery());
			criteria.setMapper(new ClaimLineDetailRecordsRowMapper(prop.getClaimLineDetailRecordsMsgType()));
			break;
		case ClaimLineEOBRecords:
			criteria.setTableName(prop.getClaimLineEOBRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getClaimLineEOBRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getClaimLineEOBRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getClaimLineEOBRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getClaimLineEOBRecordsDataQuery());
			criteria.setMapper(new ClaimLineEOBRecordsRowMapper(prop.getClaimLineEOBRecordsMsgType()));
			break;
		case ClaimPaymentRecords:
			criteria.setTableName(prop.getClaimPaymentRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getClaimPaymentRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getClaimPaymentRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getClaimPaymentRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getClaimPaymentRecordsDataQuery());
			criteria.setMapper(new ClaimPaymentRecordsRowMapper(prop.getClaimPaymentRecordsMsgType()));
			break;
		case ClaimEOBLookupRecords:
			criteria.setTableName(prop.getClaimEOBLookupRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getClaimEOBLookupRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getClaimEOBLookupRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getClaimEOBLookupRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getClaimEOBLookupRecordsDataQuery());
			criteria.setMapper(new ClaimEOBLookupRecordsRowMapper(prop.getClaimEOBLookupRecordsMsgType()));
			break;
		case ClaimInquiryRecords:
			criteria.setTableName(prop.getClaimInquiryRecordsTblName());
			if (lastProcessedDate != null && lastProcessedDate.getClaimInquiryRecordsStartDate() != null) {
				criteria.setStartDate(lastProcessedDate.getClaimInquiryRecordsStartDate());
			}
			criteria.setSqlCountRows(prop.getClaimInquiryRecordsCountQuery());
			criteria.setSqlFetchRows(prop.getClaimInquiryRecordsDataQuery());
			criteria.setMapper(new ClaimInquiryRecordsRowMapper(prop.getClaimInquiryRecordsMsgType()));
			break;
		}

		return criteria;
	}

}
