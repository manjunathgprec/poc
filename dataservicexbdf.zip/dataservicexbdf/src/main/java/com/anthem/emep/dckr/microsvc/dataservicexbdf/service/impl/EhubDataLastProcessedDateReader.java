package com.anthem.emep.dckr.microsvc.dataservicexbdf.service.impl;

import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.LastProcessedDate;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimLineDetailRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimLineEobRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimPaymentRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimSummaryRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MemberCaseRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MemberNetworkRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MembershipRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.PersonProxyRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.ClaimLineDetailRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.ClaimLineEOBRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.ClaimPaymentRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.ClaimSummaryRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.MemberCaseRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.MemberNetworkRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.MembershipRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.repository.PersonProxyRecordsRepository;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.InvalidBatchConfigurationException;

@Service
public class EhubDataLastProcessedDateReader {

	private Logger logger = LoggerFactory.getLogger(EhubDataLastProcessedDateReader.class);

	@Autowired
	private PersonProxyRecordsRepository personProxyRecordsRepository;
	@Autowired
	private MemberCaseRecordsRepository memberCaseRecordsRepository;
	@Autowired
	private MembershipRecordsRepository membershipRecordsRepository;
	@Autowired
	private MemberNetworkRecordsRepository memberNetworkRecordsRepository;
	@Autowired
	private ClaimSummaryRecordsRepository claimSummaryRecordsRepository;
	@Autowired
	private ClaimLineDetailRecordsRepository claimLineDetailRecordsRepository;
	@Autowired
	private ClaimLineEOBRecordsRepository claimLineEOBRecordsRepository;
	@Autowired
	private ClaimPaymentRecordsRepository claimPaymentRecordsRepository;

	public LastProcessedDate loadLastProcessedDate() {
		LastProcessedDate lastProcessedDate = new LastProcessedDate();

		PersonProxyRecords ehubPrsnProxyRltnshp = personProxyRecordsRepository.fetchLatestehubProxyRltn();
		MemberCaseRecords memberCaseRecords = memberCaseRecordsRepository.fetchLatestMemberCaseRecords();
		MembershipRecords membershipRecords = membershipRecordsRepository.fetchLatestMembershipRecords();
		MemberNetworkRecords memberNetworkRecords = memberNetworkRecordsRepository.fetchLatestMemberNetworkRecords();
		ClaimSummaryRecords claimSummaryRecords = claimSummaryRecordsRepository.fetchLatestClaimSummaryRecords();
		ClaimLineDetailRecords claimLineDetailRecords = claimLineDetailRecordsRepository.fetchLatestClaimLineDetailRecords();
		ClaimLineEobRecords claimLineEobRecords = claimLineEOBRecordsRepository.fetchLatestClaimLineEOBRecords();
		ClaimPaymentRecords claimPaymentRecords = claimPaymentRecordsRepository.fetchLatestClaimPaymentRecords();
		
		if (ehubPrsnProxyRltnshp != null && ehubPrsnProxyRltnshp.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setPersonProxyRecordsStartDate(DateUtil.asLocalDate(ehubPrsnProxyRltnshp.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for PersonProxyRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getPersonProxyRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}

		if (memberCaseRecords != null && memberCaseRecords.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setMemberCaseRecordsStartDate(DateUtil.asLocalDate(memberCaseRecords.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for MemberCaseRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getMemberCaseRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}

		if (membershipRecords != null && membershipRecords.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setMembershipRecordsStartDate(DateUtil.asLocalDate(membershipRecords.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for MembershipRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getMembershipRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}

		if (memberNetworkRecords != null && memberNetworkRecords.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setMemberNetworkRecordsStartDate(DateUtil.asLocalDate(memberNetworkRecords.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for MemberNetworkRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getMemberNetworkRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}

		if (claimSummaryRecords != null && claimSummaryRecords.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setClaimSummaryRecordsStartDate(DateUtil.asLocalDate(claimSummaryRecords.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for ClaimSummaryRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getClaimSummaryRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}

		if (claimLineDetailRecords != null && claimLineDetailRecords.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setClaimLineDetailRecordsStartDate(DateUtil.asLocalDate(claimLineDetailRecords.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for ClaimLineDetailRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getClaimLineDetailRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}
		
		if (claimLineEobRecords != null && claimLineEobRecords.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setClaimLineEOBRecordsStartDate(DateUtil.asLocalDate(claimLineEobRecords.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for ClaimLineEobRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getClaimLineEOBRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}
		
		if (claimPaymentRecords != null && claimPaymentRecords.getMetaRecLtstUpdtDtm() != null) {
			lastProcessedDate.setClaimPaymentRecordsStartDate(DateUtil.asLocalDate(claimPaymentRecords.getMetaRecLtstUpdtDtm()).format(DateTimeFormatter.BASIC_ISO_DATE));
			logger.warn(
					" No job start date configured for ClaimPaymentRecords and start date derived from last processed record :: "
							+ lastProcessedDate.getClaimPaymentRecordsStartDate());
		} else {
			// Throw error if no configuration or last processed record found
			throw new InvalidBatchConfigurationException("No configuration provided for job date range and no last processed record found to derive job start date");
		}
		
		return lastProcessedDate;
	}

}
