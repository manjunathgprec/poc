package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimPaymentRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;

public class ClaimPaymentRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(ClaimPaymentRecordsRowMapper.class);

	private String messageType;

	public ClaimPaymentRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public ClaimPaymentRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		ClaimPaymentRecords claimPaymentRecords = new ClaimPaymentRecords();

		// Meta fields mapping
		claimPaymentRecords.setMetaMsgType(messageType);
		claimPaymentRecords.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		claimPaymentRecords.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		claimPaymentRecords.setMetaRecLtstUpdtGuid(rs.getString("guid"));

		claimPaymentRecords.setClmMbrSorCd(rs.getString("808"));
		claimPaymentRecords.setClmId(StringUtils.trimWhitespace(rs.getString("COGS_CLM_ID")));
		claimPaymentRecords.setClmAdjstmntNbr(StringUtils.trimWhitespace(rs.getString("COGS_CLM_ADJSTMNT_NBR")));
		//Primarykey
		claimPaymentRecords.setPkeyClmPymtRefNo(StringUtils.trimWhitespace(rs.getString(claimPaymentRecords.getClmId() +"-"+ claimPaymentRecords.getClmAdjstmntNbr())));
		claimPaymentRecords.setClmTotlDdctblAmt(rs.getDouble("cogs_clm_totl_ddctbl_amt"));
		claimPaymentRecords.setClmTotlBilldChrgAmt(rs.getDouble("cogs_clm_totl_billd_chrg_amt"));
		claimPaymentRecords.setClmTotlAlwdAmt(rs.getDouble("cogs_clm_totl_alwd_amt"));
		claimPaymentRecords.setClmTotlPaidAmt(rs.getDouble("cogs_clm_totl_paid_amt"));
		claimPaymentRecords.setClmTotlCoInsuAmt(rs.getDouble("cogs_clm_totl_coinsrn_amt"));
		claimPaymentRecords.setClmTotlCoPaymntAmt(rs.getDouble("cogs_clm_totl_cpaymnt_amt"));
		claimPaymentRecords.setClmTotlNonElgAmt(rs.getDouble("cogs_clm_totl_non_cvrd_amt"));
		claimPaymentRecords.setClmTotlMbrLiablAmt(rs.getDouble("cogs_clm_totl_mbr_rspnsbly_amt"));

		return claimPaymentRecords;
	}

}
