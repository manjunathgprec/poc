package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * POJO class to represent the state of soa-bdf-grp-seg-v01
 * 
 * @author ag59866
 *
 */
@Document(collection = EventsModelConstants.MEMBERCASE_COLLECION)
public class MemberCaseRecords extends BaseEntity {

	private String pkeyMbrGrpNbr;
	private String mbrGrpSorCd;
	private String mbrGrpNbr;
	private String mbrGrpStCd;
	private String mbrNatlAcctCd;
	private Integer mbrGrpLastProcDt;

	public String getPkeyMbrGrpNbr() {
		return pkeyMbrGrpNbr;
	}

	public void setPkeyMbrGrpNbr(String pkeyMbrGrpNbr) {
		this.pkeyMbrGrpNbr = pkeyMbrGrpNbr;
	}

	public String getMbrGrpSorCd() {
		return mbrGrpSorCd;
	}

	public void setMbrGrpSorCd(String mbrGrpSorCd) {
		this.mbrGrpSorCd = mbrGrpSorCd;
	}

	public String getMbrGrpNbr() {
		return mbrGrpNbr;
	}

	public void setMbrGrpNbr(String mbrGrpNbr) {
		this.mbrGrpNbr = mbrGrpNbr;
	}

	public String getMbrGrpStCd() {
		return mbrGrpStCd;
	}

	public void setMbrGrpStCd(String mbrGrpStCd) {
		this.mbrGrpStCd = mbrGrpStCd;
	}

	public String getMbrNatlAcctCd() {
		return mbrNatlAcctCd;
	}

	public void setMbrNatlAcctCd(String mbrNatlAcctCd) {
		this.mbrNatlAcctCd = mbrNatlAcctCd;
	}

	public Integer getMbrGrpLastProcDt() {
		return mbrGrpLastProcDt;
	}

	public void setMbrGrpLastProcDt(Integer mbrGrpLastProcDt) {
		this.mbrGrpLastProcDt = mbrGrpLastProcDt;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static MemberCaseRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		MemberCaseRecords memberCase = null;
		memberCase = mapper.readValue(jsonString, MemberCaseRecords.class);
		return memberCase;
	}

}
