package com.anthem.emep.dckr.microsvc.dataservicexbdf.util;

import java.io.IOException;

import org.slf4j.MDC;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.metrics.MetricConstants;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JSONUtils {

	// Method to check if json is valid.
	public static boolean isJSONValid(String jsonInString) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			mapper.readTree(jsonInString);
			return true;
		} catch (IOException e) {
			MDC.put(MetricConstants.ERRORMSG,
					"Invalid JSON message received from the topic: " + e.getMessage() + ". Payload: " + jsonInString);
			MDC.put(MetricConstants.TRANSACTIONSTATUS, MetricConstants.FAILED);
			MDC.put(MetricConstants.STATUSCD, MetricConstants.STATUSCD_400);
			return false;
		}
	}

}
