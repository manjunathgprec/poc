package com.anthem.emep.dckr.microsvc.dataservicexbdf.util;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.Page;

/**
 * Pagination Helper class to execute db queries with pagination criteria and
 * return page data
 * 
 * @author
 *
 * @param <E>
 */
@Component
public class PaginationHelper<E> {

	Logger logger = LoggerFactory.getLogger(PaginationHelper.class);

	public long fetchTotalRowsCount(final JdbcTemplate jt, String sqlCountRows, Object args[]) {
		return jt.queryForObject(sqlCountRows, Long.class, args);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Page<E> fetchPage(final JdbcTemplate jdbcTemplate, final String sqlFetchRows, final Object args[],
			final int pageNo, final int pageSize, final RowMapper<E> rowMapper) {

		if (pageSize == 0) {
			return null;
		}

		Page<E> page = new Page<E>();

		final int startRow = (pageNo - 1) * pageSize;

		String selectSQL = sqlFetchRows + " limit " + startRow + "," + pageSize;

		jdbcTemplate.query(selectSQL, args, new ResultSetExtractor() {
			public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
				final List<E> pageItems = page.getPageItems();
				int currentRow = 0;
				while (rs.next()) {
					try {
						pageItems.add(rowMapper.mapRow(rs, currentRow++));
					} catch (Exception mappingException) {
						logger.error(" Error while mapping the DB record " + rs.getString("guid"));
					}
				}
				return page;
			}
		});
		return page;
	}

}
