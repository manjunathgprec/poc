package com.anthem.emep.dckr.microsvc.dataservicexbdf.metrics;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateTimeFormatterUtil;

@Aspect
@Component
public class MetricAdvice {
	private static final Logger logger = LoggerFactory.getLogger("SPLUNK_TRACE");
	/*
	 * @Autowired private RequestHeader requestHeader;
	 */

	String transactionId = UUID.randomUUID().toString();

	@Around(value = "execution(* *(..)) && @annotation(MethodMetric)")
	public Object calculateMethodMetric(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("PRint *****");
		Object obj = null;

		String methodName = joinPoint.getSignature().getName();
		try {
			MetricConstants.responseStatus = "NA";

			if ("onMessage".equalsIgnoreCase(methodName)) {
				String startTime = DateTimeFormatterUtil.printCurrentDateTime();
				MDC.put(MetricConstants.TRANASACTIONSTARTTIME, startTime);
				MDC.put(MetricConstants.URI, "KAFKA CONSUMER");
				MDC.put(MetricConstants.CAPTURELOCATION, "InsightConsumerMicroservice");
				MDC.put(MetricConstants.TOPICSUCMSG, "NA");
				MDC.put(MetricConstants.TOPICERRMSG, "NA");
				this.requestSplunkTracelog();
			}

			obj = joinPoint.proceed(joinPoint.getArgs());
		} finally {
			// stopWatch.stop();

			/*
			 * Feedback related TODO if
			 * ("sendInsightFeedBackToCogScale".equalsIgnoreCase(methodName)) {
			 * MDC.put(MetricConstants.URI, this.requestHeader.getRequestURI());
			 * MDC.put(MetricConstants.CAPTURELOCATION,
			 * "FeedbackProducerMicroserviceResponse"); stopWatch.stop();
			 * 
			 * this.responseSplunkTracelog(); logger.info(""); MDC.clear(); }
			 */
			if ("onMessage".equalsIgnoreCase(methodName)) {
				this.responseSplunkTracelog();
				logger.info("");
				MDC.clear();
			}

		}
		return obj;
	}

	public void requestSplunkTracelog() {
		MDC.put(MetricConstants.THREADID, String.valueOf(Thread.currentThread().getId()));
		MDC.put(MetricConstants.THREADIDHEX, String.format("%08x", Thread.currentThread().getId()));
		try {
			MDC.put(MetricConstants.NODE, InetAddress.getLocalHost().getHostName());
		} catch (IllegalArgumentException e) {
			logger.error("Exception when trying to get host name to put in splunk" + e.getMessage());
		} catch (UnknownHostException e) {
			logger.error("Exception when trying to get host name to put in splunk" + e.getMessage());

		}
		MDC.put(MetricConstants.CONSUMERSENDERID, MetricConstants.CONSUMERSENDERID_VAL);
		MDC.put(MetricConstants.TRANID, transactionId);
		MDC.put(MetricConstants.METHOD, "POST");
		MDC.put(MetricConstants.SERVICENAME, MetricConstants.SERVICE_NAME_VAL);

	}

	public void responseSplunkTracelog() {
		String endTime = DateTimeFormatterUtil.printCurrentDateTime();
		MDC.put(MetricConstants.TRANSACTIONENDTIME, endTime);
		String responseTime = DateTimeFormatterUtil
				.totalResponseTimeInSeconds(MDC.get(MetricConstants.TRANASACTIONSTARTTIME), endTime);
		MDC.put(MetricConstants.TOTALRESPONSETIME, responseTime);
	}
}