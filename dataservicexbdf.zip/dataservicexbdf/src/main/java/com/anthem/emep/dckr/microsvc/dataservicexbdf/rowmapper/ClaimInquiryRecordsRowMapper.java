package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimInquiryRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;

public class ClaimInquiryRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(ClaimInquiryRecordsRowMapper.class);

	private String messageType;

	public ClaimInquiryRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public ClaimInquiryRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		ClaimInquiryRecords claimInquiryRecords = new ClaimInquiryRecords();

		// Meta fields mapping

		return claimInquiryRecords;
	}

}
