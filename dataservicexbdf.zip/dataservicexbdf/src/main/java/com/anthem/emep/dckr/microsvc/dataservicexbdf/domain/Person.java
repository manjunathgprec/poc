package com.anthem.emep.dckr.microsvc.dataservicexbdf.domain;

import java.util.Date;
import java.util.List;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.PrsnMemberKeys;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * Class holds the person json struct data of EhubPrsnProxyRltnshp obj
 * 
 * @author AG59866
 *
 */
//@JsonPropertyOrder("")
@JsonIgnoreProperties(ignoreUnknown = true)
public class Person {

	@JsonProperty("cspersonid")
	private String csPersonId;

	@JsonProperty("prsnehubprsnid")
	private Integer prsnEhubPrsnId;

	@JsonProperty("prsnmcid")
	private String prsnMcid;

	@JsonProperty("prsnreclstupdtdtm")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	private Date prsnRecLstUpdtDtm;

	@JsonProperty("prsnmemberkeys")
	private List<PrsnMemberKeys> prsnMemberKeys;

	public String getCsPersonId() {
		return csPersonId;
	}

	public void setCsPersonId(String csPersonId) {
		this.csPersonId = csPersonId;
	}

	public Integer getPrsnEhubPrsnId() {
		return prsnEhubPrsnId;
	}

	public void setPrsnEhubPrsnId(Integer prsnEhubPrsnId) {
		this.prsnEhubPrsnId = prsnEhubPrsnId;
	}

	public String getPrsnMcid() {
		return prsnMcid;
	}

	public void setPrsnMcid(String prsnMcid) {
		this.prsnMcid = prsnMcid;
	}

	public Date getPrsnRecLstUpdtDtm() {
		return prsnRecLstUpdtDtm;
	}

	public void setPrsnRecLstUpdtDtm(Date prsnRecLstUpdtDtm) {
		this.prsnRecLstUpdtDtm = prsnRecLstUpdtDtm;
	}

	public List<PrsnMemberKeys> getPrsnMemberKeys() {
		return prsnMemberKeys;
	}

	public void setPrsnMemberKeys(List<PrsnMemberKeys> prsnMemberKeys) {
		this.prsnMemberKeys = prsnMemberKeys;
	}

}
