package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.util.Date;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

public class BaseEntity {
	
	@Id
	private String id;
	private String metaMsgType;
	private Date metaMsgCreateDtm;
	private Date metaRecLtstUpdtDtm;
	private String metaRecLtstUpdtGuid;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMetaMsgType() {
		return metaMsgType;
	}

	public void setMetaMsgType(String metaMsgType) {
		this.metaMsgType = metaMsgType;
	}

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getMetaMsgCreateDtm() {
		return metaMsgCreateDtm;
	}

	public void setMetaMsgCreateDtm(Date metaMsgCreateDtm) {
		this.metaMsgCreateDtm = metaMsgCreateDtm;
	}

	//@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss:SSS Z", timezone = "America/New_York")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss")
	public Date getMetaRecLtstUpdtDtm() {
		return metaRecLtstUpdtDtm;
	}

	public void setMetaRecLtstUpdtDtm(Date metaRecLtstUpdtDtm) {
		this.metaRecLtstUpdtDtm = metaRecLtstUpdtDtm;
	}

	public String getMetaRecLtstUpdtGuid() {
		return metaRecLtstUpdtGuid;
	}

	public void setMetaRecLtstUpdtGuid(String metaRecLtstUpdtGuid) {
		this.metaRecLtstUpdtGuid = metaRecLtstUpdtGuid;
	}

}
