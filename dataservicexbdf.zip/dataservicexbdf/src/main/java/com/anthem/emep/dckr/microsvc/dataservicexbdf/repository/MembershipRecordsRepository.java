package com.anthem.emep.dckr.microsvc.dataservicexbdf.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MembershipRecords;

@Repository
public class MembershipRecordsRepository {

	private static final Logger logger = LoggerFactory.getLogger(MembershipRecordsRepository.class);

	@Autowired
	private MongoTemplate mongoTemplate;

	public MembershipRecords fetchLatestMembershipRecords() {
		logger.info("Inside fetchLatestMembershipRecords");
		Query query = new Query();
		query.limit(1);
		query.with(new Sort(Sort.Direction.DESC, "metaRecLtstUpdtDtm"));
		MembershipRecords data = mongoTemplate.findOne(query, MembershipRecords.class);
		return data;
	}

}
