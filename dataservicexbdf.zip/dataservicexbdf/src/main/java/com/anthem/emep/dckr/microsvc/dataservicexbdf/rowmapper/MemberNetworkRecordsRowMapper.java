package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MemberNetworkRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;

public class MemberNetworkRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(MemberNetworkRecordsRowMapper.class);

	private String messageType;

	public MemberNetworkRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public MemberNetworkRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		MemberNetworkRecords memberNetworkRecords = new MemberNetworkRecords();

		// Meta fields mapping
		memberNetworkRecords.setMetaMsgType(messageType);
		memberNetworkRecords.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		memberNetworkRecords.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		memberNetworkRecords.setMetaRecLtstUpdtGuid(rs.getString("guid"));

		memberNetworkRecords.setMbrSorCd("808");
		memberNetworkRecords.setMbrGrpId(StringUtils.trimWhitespace(rs.getString("NM_CONT_GRP_SUFX_CB")));
		memberNetworkRecords.setMbrIdnSubId(StringUtils.trimWhitespace(rs.getString("NM_CERT_NO"))); //cert no?
		memberNetworkRecords.setMbrSqncNbr(rs.getInt("NM_MEMB_MBR_SEQ_NBR"));
		memberNetworkRecords.setMbrPcpId(StringUtils.trimWhitespace(rs.getString("NM_NTWK_ID_PRIMARY")));
		memberNetworkRecords.setMbrPcpEfctvDt(rs.getInt("NM_NTWK_SPRV_EFF_DT"));
		memberNetworkRecords.setMbrPcpTrmntnDt(rs.getInt("NM_NTWK_SPRV_END_DT"));
		memberNetworkRecords.setMbrPcpLstProcDt(rs.getInt("NM_NTWK_SPRV_PRC_DTE"));
		memberNetworkRecords.setMbrPcpPicSw(StringUtils.trimWhitespace(rs.getString("NM_NTWK_PIC_SW")));
		memberNetworkRecords.setMbrInsurType(""); 
		// mbrGrpId-mbrIdnSubId-mbrSqncNbr -- primary key
		memberNetworkRecords.setPkeyMbrNtkRefNo(memberNetworkRecords.getMbrGrpId() + "-" + memberNetworkRecords.getMbrIdnSubId() + "-" + memberNetworkRecords.getMbrSqncNbr());
				
		return memberNetworkRecords;

	}

}
