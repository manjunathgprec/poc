package com.anthem.emep.dckr.microsvc.dataservicexbdf.task;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.SearchCriteria;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.service.IProcessor;

/**
 * This is an interface which is intended to be executed by a thread.
 * 
 * @author AG59866
 *
 */
public class EhubDataStoreTask implements Runnable {

	Logger logger = LoggerFactory.getLogger(EhubDataStoreTask.class);

	private IProcessor processor;

	private SearchCriteria searchCriteria;

	public EhubDataStoreTask(SearchCriteria searchCriteria, IProcessor processor) {
		this.searchCriteria = searchCriteria;
		this.processor = processor;
	}

	@Override
	public void run() {
		try {
			processor.process(searchCriteria);
		} catch (Exception e) {
			logger.error("Thread execution has aborted due to", e);
		}
	}
	
	

}
