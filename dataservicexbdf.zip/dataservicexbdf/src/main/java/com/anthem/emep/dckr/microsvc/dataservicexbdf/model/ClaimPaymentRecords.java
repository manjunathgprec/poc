package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * POJO class to represent the state of ehub-clm-paymt-amt-seg-v01
 * 
 * @author ag59866
 *
 */

@Document(collection = EventsModelConstants.PAYMENT_COLLECION)
public class ClaimPaymentRecords extends BaseEntity {

	private String pkeyClmPymtRefNo;
	private String clmMbrSorCd;
	private String clmId;
	private String clmAdjstmntNbr;
	private Double clmTotlDdctblAmt;
	private Double clmTotlBilldChrgAmt;
	private Double clmTotlAlwdAmt;
	private Double clmTotlPaidAmt;
	private Double clmTotlCoInsuAmt;
	private Double clmTotlCoPaymntAmt;
	private Double clmTotlNonElgAmt;
	private Double clmTotlMbrLiablAmt;

	public String getPkeyClmPymtRefNo() {
		return pkeyClmPymtRefNo;
	}

	public void setPkeyClmPymtRefNo(String pkeyClmPymtRefNo) {
		this.pkeyClmPymtRefNo = pkeyClmPymtRefNo;
	}

	public String getClmMbrSorCd() {
		return clmMbrSorCd;
	}

	public void setClmMbrSorCd(String clmMbrSorCd) {
		this.clmMbrSorCd = clmMbrSorCd;
	}

	public String getClmId() {
		return clmId;
	}

	public void setClmId(String clmId) {
		this.clmId = clmId;
	}

	public String getClmAdjstmntNbr() {
		return clmAdjstmntNbr;
	}

	public void setClmAdjstmntNbr(String clmAdjstmntNbr) {
		this.clmAdjstmntNbr = clmAdjstmntNbr;
	}

	public Double getClmTotlDdctblAmt() {
		return clmTotlDdctblAmt;
	}

	public void setClmTotlDdctblAmt(Double clmTotlDdctblAmt) {
		this.clmTotlDdctblAmt = clmTotlDdctblAmt;
	}

	public Double getClmTotlBilldChrgAmt() {
		return clmTotlBilldChrgAmt;
	}

	public void setClmTotlBilldChrgAmt(Double clmTotlBilldChrgAmt) {
		this.clmTotlBilldChrgAmt = clmTotlBilldChrgAmt;
	}

	public Double getClmTotlAlwdAmt() {
		return clmTotlAlwdAmt;
	}

	public void setClmTotlAlwdAmt(Double clmTotlAlwdAmt) {
		this.clmTotlAlwdAmt = clmTotlAlwdAmt;
	}

	public Double getClmTotlPaidAmt() {
		return clmTotlPaidAmt;
	}

	public void setClmTotlPaidAmt(Double clmTotlPaidAmt) {
		this.clmTotlPaidAmt = clmTotlPaidAmt;
	}

	public Double getClmTotlCoInsuAmt() {
		return clmTotlCoInsuAmt;
	}

	public void setClmTotlCoInsuAmt(Double clmTotlCoInsuAmt) {
		this.clmTotlCoInsuAmt = clmTotlCoInsuAmt;
	}

	public Double getClmTotlCoPaymntAmt() {
		return clmTotlCoPaymntAmt;
	}

	public void setClmTotlCoPaymntAmt(Double clmTotlCoPaymntAmt) {
		this.clmTotlCoPaymntAmt = clmTotlCoPaymntAmt;
	}

	public Double getClmTotlNonElgAmt() {
		return clmTotlNonElgAmt;
	}

	public void setClmTotlNonElgAmt(Double clmTotlNonElgAmt) {
		this.clmTotlNonElgAmt = clmTotlNonElgAmt;
	}

	public Double getClmTotlMbrLiablAmt() {
		return clmTotlMbrLiablAmt;
	}

	public void setClmTotlMbrLiablAmt(Double clmTotlMbrLiablAmt) {
		this.clmTotlMbrLiablAmt = clmTotlMbrLiablAmt;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static ClaimPaymentRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		ClaimPaymentRecords claimPayment = null;
		claimPayment = mapper.readValue(jsonString, ClaimPaymentRecords.class);
		return claimPayment;
	}

}
