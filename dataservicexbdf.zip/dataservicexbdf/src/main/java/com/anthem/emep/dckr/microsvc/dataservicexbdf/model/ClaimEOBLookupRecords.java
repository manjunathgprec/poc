package com.anthem.emep.dckr.microsvc.dataservicexbdf.model;

import java.io.IOException;

import org.springframework.data.mongodb.core.mapping.Document;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.config.EventsModelConstants;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Document(collection = EventsModelConstants.EOBLOOKUP_COLLECION)
public class ClaimEOBLookupRecords extends BaseEntity {	

	private String pkeyClmEobCode;
	private String clmEobCode;
	private String clmEobReductField;

	public String getPkeyClmEobCode() {
		return pkeyClmEobCode;
	}

	public void setPkeyClmEobCode(String pkeyClmEobCode) {
		this.pkeyClmEobCode = pkeyClmEobCode;
	}

	public String getClmEobCode() {
		return clmEobCode;
	}

	public void setClmEobCode(String clmEobCode) {
		this.clmEobCode = clmEobCode;
	}

	public String getClmEobReductField() {
		return clmEobReductField;
	}

	public void setClmEobReductField(String clmEobReductField) {
		this.clmEobReductField = clmEobReductField;
	}

	// Method to deserialize quoted JSON string
	@JsonCreator
	public static ClaimEOBLookupRecords Create(String jsonString)
			throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		ClaimEOBLookupRecords claimEOB = null;
		claimEOB = mapper.readValue(jsonString, ClaimEOBLookupRecords.class);
		return claimEOB;
	}

}
