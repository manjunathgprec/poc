package com.anthem.emep.dckr.microsvc.dataservicexbdf.config;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "application-properties")
public class ApplicationPropertyConfig {

	private Map<String, String> kafkaproducerpropmap;

	private Map<String, String> mongodb;

	private Map<String, String> hive;

	public Map<String, String> getKafkaproducerpropmap() {
		return kafkaproducerpropmap;
	}

	public void setKafkaproducerpropmap(Map<String, String> kafkaproducerpropmap) {
		this.kafkaproducerpropmap = kafkaproducerpropmap;
	}

	public Map<String, String> getMongodb() {
		return mongodb;
	}

	public void setMongodb(Map<String, String> mongodb) {
		this.mongodb = mongodb;
	}

	public Map<String, String> getHive() {
		return hive;
	}

	public void setHive(Map<String, String> hive) {
		this.hive = hive;
	}

}
