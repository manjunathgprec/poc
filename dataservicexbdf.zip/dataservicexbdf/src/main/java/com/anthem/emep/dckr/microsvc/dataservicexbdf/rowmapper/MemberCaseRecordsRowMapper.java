package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.util.StringUtils;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.MemberCaseRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;

/**
 * This class performs the mapping of result set object per each row basis
 * 
 * @author AG59866
 * 
 */
public class MemberCaseRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(MemberCaseRecordsRowMapper.class);

	private String messageType;

	public MemberCaseRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public MemberCaseRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		MemberCaseRecords memberCaseRecords = new MemberCaseRecords();

		// Meta fields mapping
		memberCaseRecords.setMetaMsgType(messageType);
		memberCaseRecords.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		memberCaseRecords.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		memberCaseRecords.setMetaRecLtstUpdtGuid(rs.getString("guid"));

		memberCaseRecords.setPkeyMbrGrpNbr(memberCaseRecords.getMbrGrpNbr()); // Primary key
		memberCaseRecords.setMbrGrpSorCd("808");
		memberCaseRecords.setMbrGrpNbr(StringUtils.trimWhitespace(rs.getString("CS_CASE_NBR")));
		memberCaseRecords.setMbrGrpStCd(rs.getString("CS_CONT_ST"));
		memberCaseRecords.setMbrNatlAcctCd(rs.getString("CS_NATL_ACC_IND"));
		memberCaseRecords.setMbrGrpLastProcDt(rs.getInt("CS_LAST_PROC_DAT"));

		return memberCaseRecords;
	}

}
