package com.anthem.emep.dckr.microsvc.dataservicexbdf.util;

public enum TaskTypes {

	PersonProxyRecords, MemberCaseRecords, MembershipRecords, MemberNetworkRecords, ClaimSummaryRecords, ClaimLineDetailRecords, ClaimLineEOBRecords, ClaimPaymentRecords, ClaimEOBLookupRecords, ClaimInquiryRecords;

}
