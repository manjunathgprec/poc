package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.ClaimEOBLookupRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;

public class ClaimEOBLookupRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(ClaimEOBLookupRecordsRowMapper.class);

	private String messageType;

	public ClaimEOBLookupRecordsRowMapper(String messageType) {
		this.messageType = messageType;
	}

	@Override
	public ClaimEOBLookupRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		ClaimEOBLookupRecords claimEOBLookupRecords = new ClaimEOBLookupRecords();

		// Meta fields mapping

		return claimEOBLookupRecords;
	}

}
