package com.anthem.emep.dckr.microsvc.dataservicexbdf.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.anthem.emep.dckr.microsvc.dataservicexbdf.domain.Person;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.BaseEntity;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.model.PersonProxyRecords;
import com.anthem.emep.dckr.microsvc.dataservicexbdf.util.DateUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * This class performs the mapping of result set object per each row basis
 * 
 * @author AG59866
 *
 */
public class PersonProxyRecordsRowMapper implements RowMapper<BaseEntity> {

	Logger logger = LoggerFactory.getLogger(PersonProxyRecordsRowMapper.class);
	
	private String messageType;
	
	public PersonProxyRecordsRowMapper(String messageType) {
		this.messageType  = messageType;
	}

	@Override
	public PersonProxyRecords mapRow(ResultSet rs, int rowNum) throws SQLException {

		PersonProxyRecords ehubPrsnProxyRltnshp = new PersonProxyRecords();

		//Meta fields mapping
		ehubPrsnProxyRltnshp.setMetaMsgType(messageType);			
		ehubPrsnProxyRltnshp.setMetaMsgCreateDtm(new Date());
		String loadTime = rs.getString("load_dtm_str");

		LocalDateTime dt = LocalDateTime.parse(loadTime, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss"));
		ehubPrsnProxyRltnshp.setMetaRecLtstUpdtDtm(DateUtil.asDate(dt));
		ehubPrsnProxyRltnshp.setMetaRecLtstUpdtGuid(rs.getString("guid"));
		
		//Person fields mapping	
		String personJson = rs.getString("person_json");
		if (personJson != null) {
			Person person = null;
			try {
				person = new ObjectMapper().readValue(personJson, Person.class);
				ehubPrsnProxyRltnshp.setPkeyCsPersonId(person.getCsPersonId());
				ehubPrsnProxyRltnshp.setCsPersonId(person.getCsPersonId());
				ehubPrsnProxyRltnshp.setPrsnEhubPrsnId(person.getPrsnEhubPrsnId());
				ehubPrsnProxyRltnshp.setPrsnMcid(person.getPrsnMcid());
				ehubPrsnProxyRltnshp.setPrsnRecLstUpdtDtm(person.getPrsnRecLstUpdtDtm());
				ehubPrsnProxyRltnshp.setPrsnMemberKeys(person.getPrsnMemberKeys());
			} catch (Exception e) {
				logger.error("Error while parsing the person json  data from ehubPrsnProxyRltnshp", e);
			}
		}
		return ehubPrsnProxyRltnshp;
	}

}
